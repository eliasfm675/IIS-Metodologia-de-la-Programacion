package uo.mp.battleship.console;

import java.io.PrintStream;

import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Damage;
import uo.mp.battleship.model.player.Player;

public class ConsoleGamePresenter implements GamePresenter{

	@Override
	public void showGameStatus(Board left, Board right, boolean gameMode) {
		if (!gameMode) {
			showHeader(System.out, left);
			showBoardMinimal(left, right, System.out);
		} else {
			showHeader(System.out, left);
			showBoardFull(left, right,  System.out);
		}
		
	
}

	@Override
	public void showGameOver() {
		System.out.println("The game is over!!");
		
	}

	@Override
	public void showWinner(Player theWinner) {
		System.out.println("Now the turn is for the player " + theWinner);
		
	}

	@Override
	public void showShotMessage(Damage impact) {
		String message = null;
		switch ( impact ) {
		case NO_DAMAGE: message = "MISS!!! LOSE YOUR TURN ";
				break;
		case SEVERE_DAMAGE: message = "HIT!!! REPEAT";
				break;
		case MASSIVE_DAMAGE: message = "HIT AND SUNK!!! REPEAT";
				break;
		}
		System.out.println( message );
		
	}

	@Override
	public void showTurn(Player player) {
		System.out.println("Now the turn is for the player " + player);
		
	}

	@Override
	public void showShootingAt(Coordinate coordinate) {
		System.out.println("Shoot at " + coordinate.toUserString());
		
	}
	private void showBoardFull(Board playerBoard, Board computerBoard, PrintStream out) {
		char[][] board = playerBoard.getFullStatus();
		char [][] cboard = computerBoard.getFullStatus();
		int counter = 1;
		int space = 1;
		for(int i=0; i<board.length; i++) {
			if(counter<10) {
				out.print(" " + counter+"|");
			}else {
				out.print(counter+"|");
			}
			
			counter++;
			for(int j=0; j<board[0].length; j++) {
				out.print(board[i][j] + "|");
			}
			out.print("                                 ");
			if(space<10) {
				out.print(" " + space+"|");
			}else {
				out.print(space+"|");
			}
			
			space++;
			for(int k=0; k<cboard[0].length; k++) {
				out.print(cboard[i][k] + "|");
			}
			out.println();
		}
	}
	private void showBoardMinimal(Board playerBoard, Board computerBoard, PrintStream out) {
		char[][] board = playerBoard.getFullStatus();
		char [][] cboard = computerBoard.getMinimalStatus();
		int counter = 1;
		int space = 1;
		for(int i=0; i<board.length; i++) {
			if(counter<10) {
				out.print(" " + counter+"|");
			}else {
				out.print(counter+"|");
			}
			
			counter++;
			for(int j=0; j<board[0].length; j++) {
				out.print(board[i][j] + "|");
			}
			out.print("                                 ");
			if(space<10) {
				out.print(" " + space+"|");
			}else {
				out.print(space+"|");
			}
			
			space++;
			for(int k=0; k<cboard[0].length; k++) {
				out.print(cboard[i][k] + "|");
			}
			out.println();
		}
	}
	private void showHeader(PrintStream out, Board board) {
		char[] letters = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','0','P','Q','R','S','T'};
		out.print("   ");
		for(int i=0; i<board.getInnerArray().length;i++) {
			out.print(letters[i] + " ");
		}
		out.print("                                    ");
		for(int i=0; i<board.getInnerArray().length;i++) {
			out.print(letters[i] + " ");
		}
		out.println();
	}
}
