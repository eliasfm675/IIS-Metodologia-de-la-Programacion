package uo.mp.battleship.console;

import uo.mp.battleship.interaction.Console;

import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.model.board.Coordinate;

public class ConsoleGameInteractor implements GameInteractor{

	@Override
	public Coordinate getTarget() {
		System.out.print("Col (letter): ");

		char caracter = Console.readChar();
		caracter = (caracter + " ").toUpperCase().charAt(0);

		int x = caracter - 'A';

		System.out.print("Row (number): ");

		int y = Console.readInt() - 1;

		return new Coordinate(x, y);
	}

}
