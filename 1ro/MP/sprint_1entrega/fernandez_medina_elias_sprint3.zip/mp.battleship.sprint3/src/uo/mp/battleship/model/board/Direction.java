package uo.mp.battleship.model.board;

public enum Direction {
NORTH, SOUTH, EAST, WEST;
}
