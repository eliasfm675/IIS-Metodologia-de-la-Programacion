/**
 * 
 */
package uo.mp.lab02.bugs;

import uo.mp.lab02.bugs.ui.Application;

/**
 * @author mp-profes
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Application().run();
	}

}
