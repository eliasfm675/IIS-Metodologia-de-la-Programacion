package uo.mp.battleship.model.player;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.util.check.ArgumentChecks;

public class HumanPlayer {
	private String name;
	private Board myShips;
	private Board myOpponentShips;
	public HumanPlayer(String name) {
		ArgumentChecks.isTrue(!name.isBlank(), "Nombre inválido");
		ArgumentChecks.isTrue(name!=null,"Nombre inválido");
		this.name = name;
	}


	public String getName() {
		return name;
	}

	public void setMyShips(Board board) {
		myShips = board;
	}

	public void setOpponentShips(Board board) {
		myOpponentShips = board;
		
	}

	public boolean shootAt(Coordinate position) {
		return myOpponentShips.shootAt(position);
	}

	public Board getMyShips() {
		return myShips;
	}

	public Board getOpponentShips() {
		return myOpponentShips;
	}

	public boolean hasWon() {
		return myOpponentShips.isFleetSunk();
	}


	public Coordinate makeChoice() {
		Scanner scanner = new Scanner(System.in);
	    System.out.print("Ingrese la columna (A-J): ");
		String columnStr = scanner.next();
		int column = columnStr.charAt(0) - 'A';
		System.out.print("Ingrese la fila (1-10): ");
		int row = scanner.nextInt() - 1;
		scanner.close();
		return new Coordinate(column, row);
		
	}
	
}
