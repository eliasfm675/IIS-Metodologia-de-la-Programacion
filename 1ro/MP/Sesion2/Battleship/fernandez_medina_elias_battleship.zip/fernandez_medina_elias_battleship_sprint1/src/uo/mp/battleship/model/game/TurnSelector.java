package uo.mp.battleship.model.game;

class TurnSelector {
	/**
	 * COnstantes de turnos
	 */
	public static final int MACHINE_TURN = 0;
	public static final int PLAYER_TURN = 0;
	
	private int turn;
	TurnSelector() {
		
	}
	
	int next() {
		turn = (turn == PLAYER_TURN) ? MACHINE_TURN : PLAYER_TURN;
		return turn;
	}
}

