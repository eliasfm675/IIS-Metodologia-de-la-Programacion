package uo.mp.battleship.model.game;

import uo.mp.battleship.interaction.ConsoleWriter;
import uo.mp.battleship.model.player.ComputerPlayer;
import uo.mp.battleship.model.player.HumanPlayer;

public class Game {
	/**
	 * Constantes para el tamaño de los tableros
	 */
	public static final int BOARD_SIZE = 10;
	private HumanPlayer human;
	private ComputerPlayer computer;
	private boolean debugMode;
	private int[][] humanBoard;
	private int[][] computerBoard;
	public Game(HumanPlayer human, ComputerPlayer computer) {
		this.human = human;
		this.computer = computer;
		this.debugMode = false;
		humanBoard = new int[BOARD_SIZE][BOARD_SIZE];
		computerBoard = new int[BOARD_SIZE][BOARD_SIZE];
		TurnSelector turnSelector = new TurnSelector();
		ConsoleWriter presenter = new ConsoleWriter();
		
		
		
	}
	
	public void setDebugMode ( boolean gameMode ) {
		this.debugMode = gameMode;
	}

	public void play() {
	}


}
