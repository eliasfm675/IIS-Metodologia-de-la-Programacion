package uo.mp.battleship.model.board;

import java.util.ArrayList;

public class Board {
	/**
	 * Constante de dimensión del tablero
	 */
	private static final int GRID_SIZE = 10;
	/**
	 * Numero privisonal de barcos
	 */
	private static final int SHIP_NUMBER = 10;
	/**
	 * COnstantes de referencia a los barcos
	 */
	private static final char BATTLESHIP = 'B';
	private static final char CRUISER = 'C';
	private static final char DESTROYER = 'D';
	private static final char SUBMARINE = 'S';
	private static final char HIT = '*';
	private static final char MISSED_SHOT = 'Ø';
	private static final char BLANK = ' ';
	
	private ArrayList<String> list;
	private int[][] grid;
	public Board( int size ) {
		BoardBuilder board= new BoardBuilder();
		list = new ArrayList<String>();
	}

	public boolean shootAt(Coordinate position) {
		for(int i=0; i<grid.length; i++) {
			for(int j=0; j<grid[0].length; j++) {
				if(grid[i][j]>0) {
					grid[i][j]*=-1;
					return true;
				}else if(grid[i][j]==0) {
					grid[i][j]=-10;
					return false;
				}else {
					return true;
				}
			}
		}
	}	
	
	public boolean isFleetSunk() {
		int counter = 0;
		for(int i=0; i<grid.length; i++) {
			for(int j=0; j<grid[0].length; j++) {
				if(grid[i][j]<0 && grid[i][j]!=-10) {
					counter++;
				}
			}
		}
		return counter==10;
	}
	
	
	public int getSize() {
		return grid.length * grid[0].length;
	}

	public char[][] getFullStatus() {
		return null;
	}

	public char[][] getMinimalStatus() {
		return null;
		
	}
	/**
	 * Método que devuelve una copia del array(grid)
	 */
	protected int[][] getInnerArray(){
		int[][] copy = new int[grid.length][grid[0].length];
		for(int i=0; i<grid.length; i++) {
			for(int j=0; j<grid[0].length; j++) {
				copy[i][j]=grid[i][j];
			}
		}
		return copy;
	}

}
