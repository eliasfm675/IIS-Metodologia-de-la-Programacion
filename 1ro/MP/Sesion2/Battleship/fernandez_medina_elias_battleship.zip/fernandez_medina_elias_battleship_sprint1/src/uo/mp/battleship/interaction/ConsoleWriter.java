package uo.mp.battleship.interaction;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;


public class ConsoleWriter {

	public void showGameStatus(Board left, Board right, boolean debugMode) {
		
	}	

	/*
	 * Expected message 
	 * 		The winner is ... winner name
	 */
	public void showWinner(String winner) {

	}

	/*
	 * Expected message
	 * 		The game is over!!
	 */
	public void showGameOver() {

	}
	
	/*
	 * Expected message
	 * 		Now the turn is for the player player name
	 */
	public void showTurn(String playerName) {

	}

	/*
	 * Expected message
	 * 		Shoot at user-friendly
	 */
	public void showShootingAt(Coordinate position) {
		

	}

	/*
	 * Expected message
	 * 		Depending on the shot result:
	 * 		MISS, HIT!! (sprint 1)
	 * 		MISS, HIT!!. Continue, HIT AND SUNK!!. Continue (from sprint 2 on)
	 */
	public void showShotMessage(boolean damage) {
				
	}
}