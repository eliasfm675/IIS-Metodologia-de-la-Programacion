package uo.mp;

import uo.mp.newsstand.ui.UserInterface;

public class Main {

	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		new UserInterface().show();
	}

}
