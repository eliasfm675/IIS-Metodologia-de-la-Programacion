package uo.mp.newsstand.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.newsstand.exception.NewsstandException;
import uo.mp.util.log.Logger;

public class loadFileTest {
	Newsstand ns = new Newsstand();
	String fileName = "FileUtil";
//	@BeforeEach
//	public void setUp() throws Exception {
//		
//		
//	}
	/**
	 * Clase de pruebas del método loadFile. Casos de uso.
	 * 1.-Todo correcto.
	 * 2.-Nombre incorrecto (nombre menor de 5 letras) --> salta excepcion
	 */
	/**
	 * GIVEN a file whose name is longer than 5 letters
	 * WHEN trying the method loadFile
	 * THEN it adds the publications from the file to the newsstand 
	 */
	@Test
	public void loadFileAllRight() {
		try {
			ns.loadFile(fileName);
			assertTrue(ns.getPublications().size()>0);
		} catch (NewsstandException e) {
			Logger.log("No debería haber error");
		}
	}
	/**
	 * GIVEN a file whose name is shorter than 5 letters
	 * WHEN trying the method loadFile
	 * THEN it throws NewsstandException
	 */
	@Test
	public void loadFileException() {
		try {
			fileName = "dss";
			ns.loadFile(fileName);
		} catch (NewsstandException e) {
			assertEquals("Nombre del fichero menor de " + Newsstand.MIN_FILE_LENGTH, e.getMessage() );
		}
	}
	
}
