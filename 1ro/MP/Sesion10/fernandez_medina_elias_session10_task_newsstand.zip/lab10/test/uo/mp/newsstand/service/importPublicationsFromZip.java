/**
 * 
 */
package uo.mp.newsstand.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 */
class importPublicationsFromZip {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
