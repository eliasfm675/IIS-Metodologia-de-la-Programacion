package uo.mp.lab05.shapes;

public enum Colour {
	RED, GREEN, BLUE, WHITE, BLACK, YELLOW
}
