package uo.mp.lab05.picture;

public class Picture {

}
