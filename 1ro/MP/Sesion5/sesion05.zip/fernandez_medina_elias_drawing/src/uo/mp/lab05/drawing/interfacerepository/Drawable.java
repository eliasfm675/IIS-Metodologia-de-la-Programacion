/**
 * 
 */
package uo.mp.lab05.drawing.interfacerepository;
import java.io.PrintStream;
/**
 * @author uo299673
 *
 */
public interface Drawable {
	void draw(PrintStream out);
}
