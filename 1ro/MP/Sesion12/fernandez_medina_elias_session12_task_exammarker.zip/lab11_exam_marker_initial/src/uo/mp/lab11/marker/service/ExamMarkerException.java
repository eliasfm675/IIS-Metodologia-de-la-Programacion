package uo.mp.lab11.marker.service;

public class ExamMarkerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ExamMarkerException (String message) {
		super(message);
	}
}
