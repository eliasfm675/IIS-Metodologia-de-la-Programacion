package uo.mp.newsstand.domain;

import uo.mp.util.check.ArgumentChecks;

public abstract class Publication {
	private static final int MAX_LENGTH = 25;
	private String name;
	private int instock;
	private int sales;

	protected Publication(String name, int sales, int stock){
			setName(name);
			setSales(sales);
			setStock(stock);
		
		
	}

	private void setStock(int stock) {
		ArgumentChecks.isTrue( stock >= 0 && stock <=50, "Trying to create a new Publication: Illegal stock under zero or over fifty" );
		
		this.instock = stock;
	}

	private void setSales(int sales) {
		ArgumentChecks.isTrue( sales >=0 && sales <=50, "Trying to create a new Publication: Illegal sales under zero or over fifty" );
		
		this.sales = sales;
	}

	private void setName(String name) {
		ArgumentChecks.isNotNull( name, "Trying to create a new Publication: Illegal null name" );
		ArgumentChecks.isNotBlank( name, "Trying to create a new Publication: Illegal blank name" );
		ArgumentChecks.isTrue(name.length()<=MAX_LENGTH, "Trying to create a new Publication: Illegal length for name");
		this.name = name;
	}

	public String getName() {
		return name;
	}

	protected int getStock() {
		return instock;
	}

	protected int getSales() {
		return sales;
	}

	@Override
	public String toString() {
		return getName() + "\t" + getStock() + "\t" + getSales();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Publication other = (Publication) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public abstract Order generateOrders();
	public abstract String serialize();
}
