package uo.mp.util.collections.impl;

import java.nio.channels.IllegalSelectorException;
import java.util.Iterator;
import java.util.NoSuchElementException;

import uo.mp.util.collections.List;

public class ArrayList extends AbstractList implements List {
	private Object[] elements;
	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object get(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object set(int index, Object element) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(int index, Object element) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object remove(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	@Override
	public Iterator<Object> iterator(){
		return new ArrayListIterator();
	}
	
	private class ArrayListIterator implements Iterator<Object>{
		private int index;
		private Object lastReturned;
		
		private ArrayListIterator() {
			index = 0;
			lastReturned = null;
		}

		@Override
		public boolean hasNext() {
			return index < numberOfElements;
		}


		@Override
		public Object next() {
			if(hasNext()) {
				lastReturned = elements[index];
				index++;
				return lastReturned;
			}else {
				throw new NoSuchElementException("No hay más elementos");
			}
			
		}
		/**
		 * Elimina el elemento anterior al next
		 */
		@Override
		public void remove() {
			if(lastReturned!=null) {
				ArrayList.this.remove (index-1);
				index--;
				lastReturned = null;
			}else {
				throw new IllegalStateException("No es posible eliminar un objeto sin hacer previamente next");
			}
		
		}
	}

}
