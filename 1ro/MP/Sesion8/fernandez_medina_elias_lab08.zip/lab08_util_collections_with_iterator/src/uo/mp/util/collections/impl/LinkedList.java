package uo.mp.util.collections.impl;

import java.util.Iterator;
import java.util.NoSuchElementException;

import uo.mp.util.collections.List;

public class LinkedList extends AbstractList implements List {

	private Node head;
	/**
	 * Futuros metodos comunes de la super clase AbstractList
	 * size()
	 * isEmpty(), en funcion de size()
	 * contains() en funcion de indexOf() (Si es -1) contains devuelve false
	 * add(Object); en funcion de add(size(), object)
	 * remove(Object) en funcon de indexOf y remove(index)
	 * equals(Object); en funcion de get(i)
	 * hashCode(); en funcion de get(i)
	 * toString()
	 */
	private class Node{
		 Object element;
		 Node next;
	Node(Object element, Node next) {
		this.element = element;
		this.next = next;
	}
//	public int size() {
//		return numberOfElements;
//	}
//
//	public boolean isEmpty() {
//		return numberOfElements == 0;
//	}

	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean add(Object element) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	public void clear() {
		// TODO Auto-generated method stub

	}

	public Object get(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object set(int index, Object element) {
		// TODO Auto-generated method stub
		return null;
	}

	public void add(int index, Object element) {
		// TODO Auto-generated method stub

	}

	public Object remove(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Object get(int index) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Object set(int index, Object element) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void add(int index, Object element) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Object remove(int index) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public Iterator<Object> iterator() {
		return new LinkedListIterator();
	}
	private class LinkedListIterator implements Iterator<Object>{
		 private Node next;
		 private int index;
		 private Node lastReturned;
		 
	private LinkedListIterator() {
		next = head;
		index = 0;
		lastReturned = null;
	}
	

	@Override
	public boolean hasNext() {
		return next!=null;
	}

	@Override
	public Object next() {
		if(hasNext()) {
			lastReturned =  next;
			next = next.next;
			index++;
			return lastReturned.element;
		}else {
			throw new NoSuchElementException("No hay más elementos en la lista");
		}
		
	}
	@Override
	public void remove() {
		if(lastReturned!=null) {
			LinkedList.this.remove(lastReturned); //para llamar al remove de la clase anterior
			lastReturned = null;
			index--;
		}
		
	}
	
	}
}
