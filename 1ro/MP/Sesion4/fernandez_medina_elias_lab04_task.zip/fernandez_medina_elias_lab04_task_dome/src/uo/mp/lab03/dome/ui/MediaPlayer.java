/**
 * 
 */
package uo.mp.lab03.dome.ui;

import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Dvd;
import uo.mp.lab03.dome.model.Platform;
import uo.mp.lab03.dome.model.VideoGame;
import uo.mp.lab03.dome.service.MediaLibrary;

/**
 * @author uo299673
 *
 */
public class MediaPlayer {

    public void run() {
	Cd cd = new Cd("String", "String", 2, 2, true, "String", 0);
	Dvd dvd = new Dvd("String", "String", 20, true, "String", 0);
	VideoGame vg = new VideoGame("String", 20, "String", true, "String", 20, Platform.PLAYSTATION, 0);
	MediaLibrary ml = new MediaLibrary();
	ml.add(cd);
	ml.add(dvd);
	ml.add(vg);
	System.out.println("--------------Número de items con propietario" + ml.numberOfItemsOwned());
	System.out.println("--------------Listado de Ítems");
	System.out.println("--------------Resonsables" + ml.getResponsables());
	ml.list(System.out);
	ml.list2(System.out);
    }

}
