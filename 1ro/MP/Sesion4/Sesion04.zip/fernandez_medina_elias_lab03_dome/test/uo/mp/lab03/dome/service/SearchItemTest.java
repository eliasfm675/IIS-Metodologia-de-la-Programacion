package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import uo.mp.lab03.dome.model.Cd;

//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
//tienees que cambiar los test
class SearchItemTest {
    private String theTitle;
    private boolean gotIt;
    private String theComment;
    private MediaLibrary ml;
    private Cd cd;

    @BeforeEach
    public void setUp() {
	theTitle = "Come Together";
	gotIt = false;
	theComment = "No comment";
	ml = new MediaLibrary();
	Cd cdEqual = new Cd("Hola", "Adios", 0, 0, gotIt, theComment);
    }

    /**
     * Clase de pruebas del método searchItem(). Casos de uso:
     * 1.-Encuentra el item
     * 2.-No lo encuentra --> devuelve null
     * 3.-EL item es null
     * 4.-Varios items distintos pero con el mismo contenido
     */
    /**
     * GIVEN valid arguments and an empty arrayList
     * WHEN adding an item to a list
     * THEN returns said item when calling this method
     */
    @Test
    public void searchItemFound() {
	Cd cd = new Cd("Hola", "Adios", 0, 0, gotIt, theComment);
	ml.add(cd);
	assertEquals(cd, ml.searchItem(cd));
    }

    /**
     * GIVEN valid arguments and an empty arrayList
     * WHEN not adding an item to a list
     * THEN returns null
     */
    @Test
    public void searchItemNotFound() {
	Cd cd = (Cd) anItem;

	assertNull(ml.searchItem(cd));
    }

    /**
     * GIVEN null
     * WHEN searching for null
     * THEN returns null
     */
    @Test
    public void searchItemNull() {
	assertNull(ml.searchItem(null));
    }

    /*
     * GIVEN Library with some items cd, dvd and videogame
     * WHEN an item is seacrhed for with the same data as one
     */
    @Test
    public void itemSameDataExist() {
	assertEquals(cd, ml.search(cdEqual));
	assertEquals(dvd, ml.search(dvdEqual));
	assertEquals(vg, ml.search(vgEqual));
    }
}
