package uo.mp.battleship.menu;

import uo.mp.util.console.Console;

public class Menu {

	public static final int EXIT = 0;
	
	private String[] options;
	
	public Menu(String[] options) {
		this.options = options;
	}

	public Menu showOptions() {
		Console.println("\nAvailable options:");
		int i = 1;
		for(String s: options) {
			Console.println( String.format("  %d- %s\n", i++, s) );
		}
		Console.println( String.format("  %d- %s\n", 0, "Exit") );
		return this;
	}

	public int askOption() {
		int opt = EXIT;
		do {
			Console.print("Option? ");
			opt = Console.readInt();
		} while ( opt < 0 || opt > options.length );
		
		return opt;
	}

}
