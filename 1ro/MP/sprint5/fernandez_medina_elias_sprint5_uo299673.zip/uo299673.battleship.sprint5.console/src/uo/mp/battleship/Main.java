package uo.mp.battleship;

import java.io.IOException;

import uo.mp.battleship.console.ConsoleGameInteractor;
import uo.mp.battleship.console.ConsoleGamePresenter;
import uo.mp.battleship.console.ConsoleSessionInteractor;
import uo.mp.battleship.session.GameSession;

public class Main {
	
	private static final String RANKING_FILE = "battleship.rnk";
	private static final String LOG_FILE = "battleship.log";
	
	private GameSession session = new GameSession();

	public static void main(String[] args) {
		new Main()
			.configure()
			.run();
	}

	private Main configure() {
		session.setSessionInteractor( new ConsoleSessionInteractor() );
		session.setGameInteractor( new ConsoleGameInteractor() );
		session.setGamePresenter( new ConsoleGamePresenter() );
		session.setLoggerFile( LOG_FILE );
		try {
			session.setGameRankingFile( RANKING_FILE );
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		

		return this;
	}

	private void run() {
		session.run();
	}

}
