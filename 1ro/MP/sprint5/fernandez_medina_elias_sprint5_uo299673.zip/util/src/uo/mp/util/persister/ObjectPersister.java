package uo.mp.util.persister;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjectPersister {
	public static Object load(String arg) throws IOException, ClassNotFoundException {
		
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(arg));) {
			// Method for deserialization of object
			return in.readObject();
		} 
	}

	public static void save(String arg, Serializable object) throws FileNotFoundException, IOException {
		//Saving of object in a file
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(arg));
         
        // Method for serialization of object
        out.writeObject(object);
         
        out.close();
	}

}