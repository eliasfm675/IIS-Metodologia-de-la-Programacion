/**
 * 
 */
package uo.mp.battleship.model.game;

import static org.junit.Assert.assertTrue;

import org.junit.Test;


import uo.mp.battleship.model.player.Player;



/**
 * @author 
 *
 */
public class TurnSelectorTest {
	
	/*
	 * Casos:
	 * 1.- Comprueba que dos llamadas consecutivas a next(), devolverán jugadores alternados.
	 * 2.- Comprueba que, después de ejecutar repeat(), next() devolverá el mismo jugador de nuevo
	 */
	
	/**
	 * GIVEN two players
	 * WHEN called turn selector
	 * THEN it should be rigth
	 */
	 @Test
	    public void testNextAlternatingPlayers() {
	        Player humanPlayer = new Player("Human");
	        Player computerPlayer = new Player("Computer");
	        TurnSelector turnSelector = new TurnSelector(humanPlayer, computerPlayer);

	       
	        assertTrue(turnSelector.next() != turnSelector.next());
	    }
}
