/**
 * 
 */
package uo.mp.battleship.model.board;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.battleship.model.board.squares.Target;
import uo.mp.battleship.model.board.squares.Water;

/**
 * @author
 *
 */
public class SqaureTest {

	/*
	 * Casos:
	 * 1.- Disparo a agua, devuelve NO_DAMAGE
	 * 2.- Disparo a un submarino, devuelve MASSIVE_DAMAGE
	 * 3.- Disparo a una posición de un destructor, devuelve SEVERE_DAMAGE
	 * 4.- Disparo a la última posición del destructor, que lo hunde, devuelve MASSIVE_DAMAGE
	 */
	
	/**
	 * GIVEN a square and target(water)
	 * WHEN called setContent(water) and shot at there
	 * THEN NO_DAMAGE is the answer
	 */
	@Test
    public void testShootAt_WaterSquare_ReturnsNoDamage() {
        Square square = new Square();
        Target water = new Water();
        square.setContent(water);

        assertEquals(Damage.NO_DAMAGE, square.shootAt());
    }

	/**
	 * GIVEN a square and target(submarine)
	 * WHEN called setContent(submarine) and shot at there
	 * THEN MASSIVE_DAMAGE is the answer
	 */
    @Test
    public void testShootAt_SubmarineSquare_ReturnsMassiveDamage() {
        Square square = new Square();
        Target submarine = new Ship(1); // Assuming submarine is represented by a ship with size 1
        square.setContent(submarine);

        assertEquals(Damage.MASSIVE_DAMAGE, square.shootAt());
    }

    /**
	 * GIVEN a square and target(destroyer)
	 * WHEN called setContent(destroyer) and shot at there
	 * THEN SEVERE_DAMAGE is the answer
	 */
    @Test
    public void testShootAt_DestroyerSquare_ReturnsSevereDamage() {
        Square square = new Square();
        Target destroyer = new Ship(2); // Assuming destroyer is represented by a ship with size 2
        square.setContent(destroyer);

        assertEquals(Damage.SEVERE_DAMAGE, square.shootAt());
    }

    /**
	 * GIVEN a square and target(destroyer)
	 * WHEN called setContent 2 times at destroyer
	 * THEN MASSIVE_DAMAGE is the answer
	 */
    @Test
    public void testShootAt_LastPositionOfDestroyer_ReturnsMassiveDamage() {
        Square square = new Square();
        Target destroyer = new Ship(2); // Assuming destroyer is represented by a ship with size 2
        square.setContent(destroyer);

        
        square.shootAt(); // First shot
        assertEquals(Damage.MASSIVE_DAMAGE, square.shootAt()); // Second shot, sinking the destroyer
    }
}
