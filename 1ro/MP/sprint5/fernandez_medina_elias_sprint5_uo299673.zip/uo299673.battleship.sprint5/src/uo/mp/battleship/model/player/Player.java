package uo.mp.battleship.model.player;

import java.util.ArrayList;
import java.util.List;

import uo.mp.battleship.exceptions.InvalidCoordinateException;
import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.util.check.StateChecks;

public class Player {

	protected String name;
	private Board myShips;
	private Board opponentShips;
	protected List<Coordinate> firedCoordinates = new ArrayList<Coordinate>();
	private GameInteractor interactor;

	public Player(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setMyShips(Board board) {
		this.myShips = board;
	}

	public void setOpponentShips(Board board) {
		this.opponentShips = board;
	}

	public Damage shootAt(Coordinate position) throws InvalidCoordinateException {
		return opponentShips.shootAt(position);
	}

	public Board getMyShips() {
		return myShips;
	}

	public Board getOpponentShips() {
		return opponentShips;
	}

	public boolean hasWon() {
		return opponentShips.isFleetSunk();
	}
	
	public Coordinate makeChoice() {
		Coordinate randomCoordinate = null;
		do {
			StateChecks.isTrue(interactor != null);
			randomCoordinate = interactor.getTarget();
	        
		}while(firedCoordinates.contains(randomCoordinate));
			firedCoordinates.add(randomCoordinate);
        	return randomCoordinate;
	}
	
	public void setInteractor(GameInteractor arg) {
		this.interactor = arg;
	}

}