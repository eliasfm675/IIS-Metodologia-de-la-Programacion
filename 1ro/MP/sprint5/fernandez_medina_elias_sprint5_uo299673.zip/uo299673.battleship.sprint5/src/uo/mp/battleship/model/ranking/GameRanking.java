package uo.mp.battleship.model.ranking;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uo.mp.battleship.model.ranking.comparator.RankingComparator;
import uo.mp.util.log.Logger;
import uo.mp.util.persister.ObjectPersister;

public class GameRanking {
	private List<Score> scores = new ArrayList<Score>();

	public GameRanking(String rankingFileName) throws FileNotFoundException, IOException, ClassNotFoundException {
		 if(emptyFile(rankingFileName))
	            ObjectPersister.save("battleship.rnk", (Serializable) scores);
	        this.scores = (List<Score>) ObjectPersister.load(rankingFileName);
	        

	}

	public void append(Score score) throws IOException {
		scores.add(score);
		ObjectPersister.save("battleship.rnk", (Serializable) scores);

	}

	public List<Score> getRanking() {
		List<Score> scoresCopy = new ArrayList<Score>();
		for (Score score : scores) {
			scoresCopy.add(score);
		}
		return scoresCopy;
	}

	public List<Score> getRankingFor(String username) {
		List<Score> scoresCopy = new ArrayList<Score>();
		for (Score score : scores) {
			if (score.getUserName().equals(username))
				scoresCopy.add(score);
		}
		return scoresCopy;
	}
	private boolean emptyFile(String fileName) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        try {
            String line=reader.readLine();
            if(line==null || line==" ") {
            	return true;
            }else {
            	return false;
            }
        }finally {
            reader.close();
        }
    }
	public void sortRanking() throws FileNotFoundException, IOException {
		Collections.sort(scores, new RankingComparator());
		  ObjectPersister.save("battleship.rnk", (Serializable) scores);
	}

	public void sortPersonalRanking() throws FileNotFoundException, IOException {
		Collections.sort(scores);
		  ObjectPersister.save("battleship.rnk", (Serializable) scores);
	}
}
