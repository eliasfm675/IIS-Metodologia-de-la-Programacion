package uo.mp.battleship.model.board;

import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Target;

public class Square {
	
	private Target content;
	private boolean shot;
	
	public Square() {
		shot = false;
	}
	
	Damage shootAt() {
		shot = true;
		return content.shootAt();
	}
	
	boolean isShot() {
		return shot;
	}
	
	char toChar() {
		if(shot) {
			return content.toFiredChar();
		}
		
		return content.toChar();
	}
	
	Square setContent(Target content) {
		this.content = content;
		return this;
	}
	
	boolean hasContent() {
		if(content instanceof Target) {
			return true;
		}
		return false;
	}
}
