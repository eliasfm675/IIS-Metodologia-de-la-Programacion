/**
 * 
 */
package uo.mp.battleship.model.ranking;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Collections;

import uo.mp.battleship.session.GameLevel;

/**
 * 
 */
public class Score implements Serializable, Comparable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private GameLevel level;
	private LocalDateTime initial;
	private LocalDateTime finalTime;

	public Score(String userName, GameLevel level, LocalDateTime initial, LocalDateTime finalTime) {
		this.userName = userName;
		this.level = level;
		this.finalTime = finalTime;
		this.initial = initial;

	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the level
	 */
	public GameLevel getLevel() {
		return level;
	}

	public long getTime() {
		return ChronoUnit.SECONDS.between(initial, finalTime);
	}

	public LocalDateTime getDate() {
		return finalTime;
	}

	public String toString() {
		return getUserName()+"\t\t"+ 
				getCurrentDate() + "\t\t" + getCurrentHour() + 
					"\t\t" + getLevel() + "\t" + getTime();

	}
	
	public String personalToString() {
		return getCurrentDate() + "\t\t" + getCurrentHour() + 
					"\t\t" + getLevel() + "\t" + getTime();

	}

	private String getCurrentHour() {
		LocalDateTime locaDate = LocalDateTime.now();
		int hours = locaDate.getHour();
		int minutes = locaDate.getMinute();
		int seconds = locaDate.getSecond();
		String time = String.format("%d:%d:%d", hours,minutes,seconds);
		return time;

	}
	
	private String getCurrentDate() {
		LocalDateTime locaDate = LocalDateTime.now();
		int day = locaDate.getDayOfMonth();
		int month = locaDate.getMonthValue();
		int year = locaDate.getYear();
		String date = String.format("%d-%d-%d", day,month,year);
		return date;

	}

	@Override
	public int compareTo(Object o) {
        if(((Score) o).getDate().compareTo(this.getDate())==0) {
            return ((Score) o).getCurrentHour().compareTo(this.getCurrentHour());
        }else {
            return ((Score) o).getDate().compareTo(this.getDate());
        }
    }


}
