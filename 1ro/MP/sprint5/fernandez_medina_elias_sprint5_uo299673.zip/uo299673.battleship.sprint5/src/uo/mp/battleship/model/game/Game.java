package uo.mp.battleship.model.game;


import java.time.LocalDateTime;

import uo.mp.battleship.exceptions.InvalidCoordinateException;
import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;

import uo.mp.battleship.model.player.Player;
import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.check.StateChecks;

public class Game {

	private Player humanPlayer;
	private Player computerPlayer;
	private Board humanBoard;
	private Board computerBoard;
	private TurnSelector turnSelector;
	private GamePresenter consoleWriter;
	private boolean gameMode;
	private LocalDateTime initialTime;
	private LocalDateTime finalTime;

	public Game(Player human, Player computer, int size) {
		ArgumentChecks.isTrue(size >= 10 && size <= 20, "Size is out of bounds");
		this.humanPlayer = human;
		this.computerPlayer = computer;
		this.humanBoard = new Board(size);
		this.computerBoard = new Board(size);
		
		
		
		this.humanPlayer.setMyShips(humanBoard);
		this.computerPlayer.setOpponentShips(humanBoard);
		this.humanPlayer.setOpponentShips(computerBoard);
		this.computerPlayer.setMyShips(computerBoard);

		this.turnSelector = new TurnSelector(human, computer);
		
		
	}
	
	public void setPresenter(GamePresenter arg) {
		this.consoleWriter = arg;
	}
	
	public Game(Player human, Player computer) {
        this(human, computer, 10);
    }

	public void setDebugMode(boolean gameMode) {
		this.gameMode = gameMode;
	}
	
	public LocalDateTime getInitialTime() {
		return initialTime;
	}
	
	public LocalDateTime getFinalTime() {
		return finalTime;
	}

	public void play() {
        boolean win = false;
        Damage hom;
        Coordinate coord;
        Player currentPlayer = turnSelector.next();
        this.initialTime = LocalDateTime.now();
        gameLoop(win, currentPlayer);
        this.finalTime = LocalDateTime.now();
    }

	private void gameLoop(boolean win, Player currentPlayer) {
		Damage hom;
		Coordinate coord;
		while(!win) {
            try {
                while (!win) {
                    StateChecks.isTrue(consoleWriter != null);
                    consoleWriter.showGameStatus(humanBoard, computerBoard, gameMode);
                    consoleWriter.showTurn(currentPlayer);
                    coord = currentPlayer.makeChoice();
                    consoleWriter.showShootingAt(coord);
                    hom = currentPlayer.shootAt(coord);
                    consoleWriter.showShotMessage(hom);
                    if(currentPlayer.getOpponentShips().isFleetSunk()) {
                        win = true;
                    }else {
                        currentPlayer = turnSelector.next();
                    }
                }
            }catch(InvalidCoordinateException e) {
                consoleWriter.showErrorMessage(e.getMessage());
                currentPlayer = turnSelector.next();
            }
        }
	}

}
