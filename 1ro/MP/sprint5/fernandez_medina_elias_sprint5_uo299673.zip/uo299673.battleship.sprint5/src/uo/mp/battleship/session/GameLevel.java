package uo.mp.battleship.session;

public enum GameLevel {
	PLANET, OCEAN, SEA;
}
