/**
 * 
 */
package uo.mp.battleship.model.board.squares;

/**
 * @author
 *
 */
public enum Damage {
	SEVERE_DAMAGE, MASSIVE_DAMAGE, NO_DAMAGE;
}
