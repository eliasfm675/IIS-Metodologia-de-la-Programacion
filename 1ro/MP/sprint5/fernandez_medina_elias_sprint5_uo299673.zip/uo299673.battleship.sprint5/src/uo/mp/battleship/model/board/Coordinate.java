package uo.mp.battleship.model.board;

import java.util.Objects;

public class Coordinate {

	private int x;
	private int y;

	public Coordinate(int x, int y) {
		setX(x);
		setY(y);
	}

	private void setY(int y) {
		this.y = y;

	}

	private void setX(int x) {
		this.x = x;

	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Coordenada ").append("[x = ").append(getX()).append(", ").append("y = ").append(getY()).append("]");
		return sb.toString();
	}

	public String toUserString() {
		char xChar = (char) ('A' + x);
		return String.format("%s-%d", xChar, y);
	}

	@Override
	public int hashCode() {
		return Objects.hash(x, y);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (getClass() != o.getClass())
			return false;
		Coordinate other = (Coordinate) o;
		return x == other.x && y == other.y;
	}
	
	public Coordinate go(Direction direction) {
		if(direction == Direction.NORTH) {
			return new Coordinate(getX() -1, getY());
		}
		
		else if(direction == Direction.EAST) {
			return new Coordinate(getX(), getY() +1);
		}
		
		else if(direction == Direction.WEST) {
			return new Coordinate(getX(), getY() -1);
		}
		
		else {
			return new Coordinate(getX() +1, getY());
		}
	}

}
