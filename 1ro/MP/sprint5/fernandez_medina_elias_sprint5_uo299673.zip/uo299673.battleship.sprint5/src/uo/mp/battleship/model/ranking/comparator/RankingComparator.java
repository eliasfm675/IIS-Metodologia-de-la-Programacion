package uo.mp.battleship.model.ranking.comparator;

import java.util.Comparator;

import uo.mp.battleship.model.ranking.Score;

public class RankingComparator implements Comparator<Score>{

	@Override
	public int compare(Score o1, Score o2) {
		if(o1.getLevel().compareTo(o2.getLevel()) == 0) {
			if(Long.compare(o1.getTime(), o2.getTime())==0) {
				return o1.getDate().compareTo(o2.getDate());
			}else {
				return Long.compare(o1.getTime(), o2.getTime());
			}
		}else {
			return o1.getLevel().compareTo(o2.getLevel());
		}
	}

}
