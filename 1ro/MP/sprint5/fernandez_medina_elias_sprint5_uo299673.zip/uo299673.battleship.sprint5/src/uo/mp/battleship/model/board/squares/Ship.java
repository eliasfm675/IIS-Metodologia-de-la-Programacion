/**
 * 
 */
package uo.mp.battleship.model.board.squares;

import uo.mp.util.check.ArgumentChecks;

/**
 * @author
 *
 */
public class Ship implements Target{
	
	private int size;
	private int shotCount;

	public Ship(int shipSize) {
		ArgumentChecks.isTrue(shipSize >= 1 && shipSize <= 4, "Out of bounds for shipSize");
		this.size = shipSize;
		shotCount = 0;
	}
	
    public int getSize() {
        return size;
    }

    public int getShotCount() {
        return shotCount;
    }
    
    public Damage shootAt() {
        shotCount++;
        if (shotCount >= size) {
            return Damage.MASSIVE_DAMAGE; // Última casilla del barco que no había sido disparada
        } else {
            return Damage.SEVERE_DAMAGE; // El barco tiene casillas que no han sido disparadas
        }
    }
    
    public boolean isSunk() {
    	return shotCount>=size;
    }
    
    public char toChar() {
    	if(size == 4) {
    		return 'B';
    	}
    	
    	else if(size == 3) {
    		return 'C';
    	}
    	
    	else if(size == 2) {
    		return 'D';
    	}
    	
    	else if(size == 1){
    		return 'S';
    	}
    	
    	return ' ';
    }
    
    public char toFiredChar() {
    	if(shootAt() == Damage.SEVERE_DAMAGE) {
    		return '*';
    	}
    	
    	else {
    		return '#';
    	}
    }
}
