package uo.mp.battleship.exceptions;

import java.util.ArrayList;
import java.util.List;

import uo.mp.battleship.model.board.Coordinate;

public class InvalidCoordinateException extends Exception {
	private Coordinate coordinate;
	
	public InvalidCoordinateException(Coordinate c) {
		super(c.toString() +"  is out of the board. You lose your turn.");
		this.coordinate=c;
	}
	
	public Coordinate getCoordinate() {
		return coordinate;
	}
	
	

}
