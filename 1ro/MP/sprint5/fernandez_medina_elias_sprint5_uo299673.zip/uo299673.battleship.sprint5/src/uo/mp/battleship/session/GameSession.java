/**
 * 
 */
package uo.mp.battleship.session;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import uo.mp.battleship.exceptions.InvalidCoordinateException;
import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.interaction.RandomGameInteractor;
import uo.mp.battleship.interaction.SessionInteractor;
import uo.mp.battleship.model.game.Game;
import uo.mp.battleship.model.player.Player;
import uo.mp.battleship.model.ranking.GameRanking;
import uo.mp.battleship.model.ranking.Score;
import uo.mp.util.console.Console;
import uo.mp.util.log.Logger;

/**
 * 
 */
public class GameSession {
	private static final int EXIT = 0;
	private static final int NUMBER_OF_OPTIONS = 4;
	private GameInteractor interactor;
	private GamePresenter presenter;
	private SessionInteractor sInteractor;
	private GameRanking ranking;
	private Player humanPlayer;
	private Player computerPlayer;
	private Game game;
	private Logger logger;
	

	public void run() {
		try {
			String name = sInteractor.askUserName();
			humanPlayer = new Player(name);
			humanPlayer.setInteractor(interactor);
			readFile("battleship.rnk");
			computerPlayer = new Player("Computer");
			computerPlayer.setInteractor(new RandomGameInteractor(10));
			gameLoop();
		} catch (RuntimeException e) {
			Console.printError("FATAL ERROR:");
			Console.printError(e.getMessage());
			Console.printError("The program must stop execution.");
		} catch (InvalidCoordinateException e) {
			presenter.showErrorMessage(e.getMessage());
		} catch (FileNotFoundException e) {
			sInteractor.showErrorMessage(e.getMessage());

		} catch (IOException e) {
			sInteractor.showFatalErrorMessage(e.getMessage());
			logger.log(e.getMessage());
			logger.log(e);

		}

	}

	private void gameLoop() throws InvalidCoordinateException, IOException {
		while (true) {
			sInteractor.showMenu();
			int option = sInteractor.askNextOption();
			processOption(option);
			if (option == 0)
				break;
		}
	}

	private void processOption(int option) throws InvalidCoordinateException, IOException {
		switch (option) {
		case 0:
			sInteractor.sayGoodbye();
			break;
		case 1:
			gameSetup();

			break;

		case 2:
			sInteractor.showPersonalRanking(ranking.getRankingFor(humanPlayer.getName()));
			break;
		case 3:
			sInteractor.showRanking(ranking.getRanking());
			break;
		case 4:
			ranking.sortPersonalRanking();
			break;
		case 5:
			ranking.sortRanking();
			break;
		}

	}

	private void gameSetup() throws IOException {
		GameLevel level=sInteractor.askGameLevel();
		if(level.compareTo(GameLevel.SEA)==0) {
		    game =new Game(humanPlayer,computerPlayer,10);
		}else if(level.compareTo(GameLevel.OCEAN)==0) {
		    game =new Game(humanPlayer,computerPlayer,15);
		}else {
		    game =new Game(humanPlayer,computerPlayer,20);
		}
		game.setDebugMode(sInteractor.askDebugMode());
		game.setPresenter(presenter);
		game.play();
		if (sInteractor.doYouWantToRegisterYourScore()) {
			Score result = new Score(humanPlayer.getName(), level, game.getInitialTime(),
					game.getFinalTime());
			ranking.append(result);
			
		}
	}


	/**
	 * @param interactor the interactor to set
	 */
	public void setGameInteractor(GameInteractor interactor) {
		this.interactor = interactor;
	}

	/**
	 * @param presenter the presenter to set
	 */
	public void setGamePresenter(GamePresenter presenter) {
		this.presenter = presenter;
	}

	/**
	 * @param sInteractor the sInteractor to set
	 */
	public void setSessionInteractor(SessionInteractor sInteractor) {
		this.sInteractor = sInteractor;
	}

	/**
	 * @param ranking the ranking to set
	 */
	public void setGameRanking(GameRanking ranking) {
		this.ranking = ranking;
	}

	private void readFile(String fileName) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        try {
            String line;
            while((line = reader.readLine()) != null) {
            }
        }finally {
            reader.close();
        }
    }
public void setLoggerFile(String filename) {
	this.logger = new Logger(filename);
}
public void setGameRankingFile(String filename) throws FileNotFoundException, IOException, ClassNotFoundException {
	this.ranking = new GameRanking(filename);
}
}
