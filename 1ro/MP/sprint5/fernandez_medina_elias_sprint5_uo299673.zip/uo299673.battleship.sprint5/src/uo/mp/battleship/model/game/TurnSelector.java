package uo.mp.battleship.model.game;

import java.util.Random;

import uo.mp.battleship.model.player.Player;

class TurnSelector {

	private Player currentPlayer;
	private Player humanPlayer;
	private Player computerPlayer;
	TurnSelector(Player humanPlayer, Player computerPlayer) {
		Random r = new Random();
		currentPlayer = (r.nextBoolean()) ? humanPlayer : computerPlayer;
		this.computerPlayer = computerPlayer;
		this.humanPlayer = humanPlayer;
	}

	Player next() {
		if(currentPlayer == humanPlayer) {
			currentPlayer = computerPlayer;
		}else {
			currentPlayer = humanPlayer;
		}
		return currentPlayer;
	}
	
	public void repeat() {
		next();
	}
}
