/**

 * 
 */
package uo.mp.battleship.model.board;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;

/**
 * 
 */
class shootAtTest {
	private static Board board;
	private Coordinate cor;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	public static void setUp() {
		board = new Board(10);
	}
	/**
	 * Casos de uso del método shootAt(): 
	 * 1. Después de disparar una casilla aún no disparada que no contienen barco,
	 *  el método devolverá falso y la casilla en cuestión se marcará como disparada (-10).
	 *  
	 * 2. Después de disparar una casilla ya disparada que originalmente no contenía un barco,
	 *  el método debe devolver false y la casilla permanecerá como disparada (-10).
	 *  
	 * 3. Después de disparar una casilla aún no disparada que contiene un barco,
	 *  el método devolverá true y la casilla cambiará a disparada (su valor en negativo).
	 *  
	 * 4. Después de disparar una casilla disparada que originalmente contenía un barco, el
	 *  contenido permanecerá igual y el método devolverá true.
	 */
	/**
	 * GIVEN an empty position that wasn't shot before
	 * WHEN calling the method
	 * THEN the position is set to -10 and returns false
	 */
	@Test
	public void shootUpNoShip() {
		cor = new Coordinate(9, 0);
		int expectedPos = board.getInnerArray()[0][9];
		board.shootAt(cor);
		assertFalse(board.shootAt(cor));
		assertEquals(-10, expectedPos);
	}
	/**
	 * GIVEN an empty position already shot before
	 * WHEN calling the method
	 * THEN the position is still -10 and returns false
	 */
	@Test
	public void shootUpNoShipMoreThanOnce() {
		cor = new Coordinate(9, 0);
		int expectedPos = board.getInnerArray()[0][9];
		board.shootAt(cor);
		board.shootAt(cor);
		assertFalse(board.shootAt(cor));
		assertEquals(-10, expectedPos);
	}
	/**
	 * GIVEN an filled position that wasn't shot before
	 * WHEN calling the method
	 * THEN the position is set to negative and returns true
	 */
	@Test
	public void shootUpWithShip() {
		cor = new Coordinate(0, 0);
		int expectedPos = board.getInnerArray()[0][0];
		board.shootAt(cor);
		assertTrue(board.shootAt(cor));
		assertEquals(-1, expectedPos);
	}
	/**
	 * GIVEN an filled position that was already shot before
	 * WHEN calling the method
	 * THEN the position remains negative and returns true
	 */
	@Test
	public void shootUpWithShipMoreThanOnce() {
		cor = new Coordinate(0, 0);
		int expectedPos = board.getInnerArray()[0][0];
		board.shootAt(cor);
		board.shootAt(cor);
		assertTrue(board.shootAt(cor));
		assertEquals(-1, expectedPos);
	}

}
