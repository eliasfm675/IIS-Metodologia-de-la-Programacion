package uo.mp.battleship.model.game;

class TurnSelector {
	/**
	 * Constantes de turnos
	 */
	static final int PLAYER_TURN = 1;
	private static final int MACHINE_TURN = 0;
	private int turn;
	TurnSelector() {
		setTurn(MACHINE_TURN);
	}
	
	private int getTurn() {
		return turn;
	}

	private void setTurn(int turn) {
		this.turn = turn;
	}

	int next() {
		turn = (turn==PLAYER_TURN) ? MACHINE_TURN : PLAYER_TURN;
		return turn;
	}
}

