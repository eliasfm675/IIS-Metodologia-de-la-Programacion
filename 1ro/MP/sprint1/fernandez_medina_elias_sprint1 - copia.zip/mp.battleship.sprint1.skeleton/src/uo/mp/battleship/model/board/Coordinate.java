package uo.mp.battleship.model.board;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class Coordinate {
	public static final int BOARD_SIZE = 10;
		int x;
		int y;
		
	public Coordinate(int x, int y) {
		ArgumentChecks.isTrue(x>=0 && y>= 0 && x<BOARD_SIZE && y<BOARD_SIZE, "X or Y position is an invalid value for the argument");
		this.x = x;
		this.y = y;
		
	}

	public int getCol() {
		return x;
	}

	public int getRow() {
		return y;
	}
	
	@Override
	public String toString() {
		String str = String.format("Coordenada [x = %d, y = %d", getCol(), getRow());
		return str;
	}

	public String toUserString() {
		char[] characters = {'A','B','C','D','E','F','G','H','I','J'};
		return characters[getCol()] + "-" + getRow()+1;
	}

	@Override
	public int hashCode() {
		return Objects.hash(x, y);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordinate other = (Coordinate) obj;
		return x == other.x && y == other.y;
	}

}
