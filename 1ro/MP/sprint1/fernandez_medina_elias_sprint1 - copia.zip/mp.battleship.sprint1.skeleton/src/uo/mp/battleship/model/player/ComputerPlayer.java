package uo.mp.battleship.model.player;

import java.util.ArrayList;
import java.util.Random;

import uo.mp.battleship.model.board.Coordinate;

public class ComputerPlayer extends Player {
	/**
	 * Constante de dimensión del tablero
	 */
	private static final int GRID_SIZE = 10;
	private ArrayList<Coordinate> shotCoordinates;
	
	public ComputerPlayer(String name) {
		super(name);
		shotCoordinates = new ArrayList<Coordinate>();
	}
	
	@Override
	public boolean shootAt(Coordinate coordinate) {
		shotCoordinates.add(coordinate);
		return super.shootAt(coordinate);
	}
	   @Override
	    public Coordinate makeChoice() {
	        Coordinate choice = generateRandomCoordinate();
	        while (shotCoordinates.contains(choice)) {
	            choice = generateRandomCoordinate();
	        }
	        return choice;
	    }

	    private Coordinate generateRandomCoordinate() {
	        Random random = new Random();
	        int row = random.nextInt(GRID_SIZE);
	        int column = random.nextInt(GRID_SIZE);
	        return new Coordinate(row, column);
	    }

}
