package uo.mp.battleship.model.player;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.util.check.ArgumentChecks;

public abstract class Player {
	private String name;
	private Board myShips;
	private Board myOpponentShips;
	public Player(String name) {
		setName(name);
		
	}

	/**
	 * @param name the name to set
	 */
	private void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setMyShips(Board board) {
		this.myShips = board;
	}

	public void setOpponentShips(Board board) {
		this.myOpponentShips = board;
	}

	public boolean shootAt(Coordinate position) {
		return myShips.shootAt(position);
	}

	public Board getMyShips() {
		return myShips;
	}

	public Board getOpponentShips() {
		return myOpponentShips;
	}

	public boolean hasWon() {
		return myOpponentShips.isFleetSunk();
	}

	public abstract Coordinate makeChoice();

}