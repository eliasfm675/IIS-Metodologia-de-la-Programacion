package uo.mp.battleship.model.board;

import java.util.ArrayList;

public class Board {
	/**
	 * Constante de dimensión del tablero
	 */
	private static final int GRID_SIZE = 10;
	/**
	 * Numero privisonal de barcos
	 */
	private static final int SHIP_NUMBER = 10;
	/**
	 * COnstantes de referencia a los barcos
	 */
	private static final char BATTLESHIP = 'B';
	private static final char CRUISER = 'C';
	private static final char DESTROYER = 'D';
	private static final char SUBMARINE = 'S';
	private static final char HIT = '*';
	private static final char MISSED_SHOT = 'Ø';
	private static final char BLANK = ' ';

	private int[][] grid;

	public Board(int size) {
		BoardBuilder bb =new BoardBuilder();
		grid = bb.build();
	}

	public boolean shootAt(Coordinate position) {
		if (grid[position.getRow()][position.getCol()] > 0) {
			grid[position.getRow()][position.getCol()] *= -1;
			return true;
		} else if ((grid[position.getRow()][position.getCol()] == 0)
				|| (grid[position.getRow()][position.getCol()] == -10)) {
			grid[position.getRow()][position.getCol()] = -10;
			return false;
		}
		return true;

	}

	public boolean isFleetSunk() {
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				if (grid[i][j] > 0) {
					return false;
				}
			}
		}
		return true;
	}

	public int getSize() {
		return grid.length * grid[0].length;
	}

	public char[][] getFullStatus() {
		char[][] status = new char[grid.length][grid[0].length];
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				if (grid[i][j] < 0 && grid[i][j] != -10) {
					status[i][j] = '*';
				} else {
					switch (grid[i][j]) {
					case -10:
						status[i][j] = 'Ø';
						break;
					case 0:
						status[i][j] = ' ';
						break;
					case 1:
						status[i][j] = 'S';
						break;
					case 2:
						status[i][j] = 'D';
						break;
					case 3:
						status[i][j] = 'C';
						break;
					case 4:
						status[i][j] = 'B';
						break;
					}
				}
			}
		}
		return status;
	}

	public char[][] getMinimalStatus() {
		char[][] status = new char[grid.length][grid[0].length];
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				if (grid[i][j] < 0 && grid[i][j] != -10) {
					status[i][j] = '*';
				} else {
					switch (grid[i][j]) {
					case -10:
						status[i][j] = 'Ø';
						break;
					default:
						status[i][j] = ' ';
						break;
					}
				}
			}
		}
		return status;
	}

	public int[][] getInnerArray() {
		int[][] copy = new int[grid.length][grid[0].length];
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				copy[i][j] = grid[i][j];
			}
		}
		return copy;
	}


}
