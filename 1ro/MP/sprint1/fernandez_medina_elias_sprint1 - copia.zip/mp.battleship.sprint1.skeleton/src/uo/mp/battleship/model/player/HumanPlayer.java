package uo.mp.battleship.model.player;

import java.util.Scanner;

import uo.mp.battleship.interaction.ConsoleReader;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.util.check.ArgumentChecks;

public class HumanPlayer extends Player{

	public HumanPlayer(String name) {
		super(name);
		if(name==null || name.isBlank() || name.isEmpty()) {
			name="user";
		}
	}


	@Override
	public Coordinate makeChoice() {
		ConsoleReader cr = new ConsoleReader();
		return cr.readCoordinates();
	}
	
}
