package uo.mp.transaction;

import uo.mp.List;
import uo.mp.Transaction;
import uo.mp.TransactionProcessor;

public class TransactionProcessor {

	private TransactionValidator validator;

	public void process(String trxFileName) {
		
		List<Transaction> trxs = new TransactionLoader( trxFileName ).load();
		
		validator = new TransactionValidator();
		validator.add( trxs );
		validator.validate();
		
		List<Transaction> validTransactions = validator.getValidTransactions();
		List<Transaction> invalidTransactions = validator.getInvalidTransactions();

		new ValidTransactionWriter( trxFileName ).save( validTransactions );
		new InvalidTransactionWriter( trxFileName ).save( invalidTransactions );
		
		showInvalidTransactions( getInvalidTransactions() );
	}

	public List<Transaction> getInvalidTransactions() {
		return validator.getInvalidTransactions();
	}
	
	
	private void showInvalidTransactions(List<Transaction> invalidTrxs) {
		for(Transaction t: invalidTrxs ) {
			System.out.println( t );
			for(String error: t.getFaults() ) {
				System.out.println( error );
			}
		}
	}

}
