package uo.mp;

import uo.mp.transaction.TransactionProcessor;

public class Main {

	private static final String TRX_FILE_NAME = "input_transactions.trx";
//	private static final String TRX_FILE_NAME = "input_transactions_with_parsing_errors.trx";
//	private static final String TRX_FILE_NAME = "input_transactions_with_repeated_abort.trx";

	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		new TransactionProcessor().process(TRX_FILE_NAME);		
	}

	

}
