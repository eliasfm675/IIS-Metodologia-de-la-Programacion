package uo.mp.tg1.payments;



public class Main {
	
	public static void main(String[] args) {
		new Main().run();
	}
	
	private void run() {
		// crear un retailer
		
//		Crear crediCard con datos ("100", 100.0, "1111-1111-1111-1111", 12, 2018);  si es válido
//		Crear crediCard con datos ("101", 100.0, "22222222222222222222", 12, 2023); no es válido
//		Crear payPal con datos ("102", 100.0, "john@gmail.com", "@34abX!");   Si es válido 
//		Crear payPal con datos ("103", 100.0, "mary@w3c.org", "xx_xxxx" );     No es válido
//		Crear pago cash con datos ("104", 100.0);
		
//		Añadir pagos al retailer
//		Calcular venta total 
//		Imprimirla
//		
//		Procesar los pagos
//		
//		Calcular venta total
//		Imprimirla
		
		
	}

}
