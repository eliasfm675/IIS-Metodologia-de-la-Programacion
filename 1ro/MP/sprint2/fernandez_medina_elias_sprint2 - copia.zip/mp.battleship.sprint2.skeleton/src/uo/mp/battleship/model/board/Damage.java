package uo.mp.battleship.model.board;

public enum Damage {
NO_DAMAGE, SEVERE_DAMAGE, MASSIVE_DAMAGE;
}
