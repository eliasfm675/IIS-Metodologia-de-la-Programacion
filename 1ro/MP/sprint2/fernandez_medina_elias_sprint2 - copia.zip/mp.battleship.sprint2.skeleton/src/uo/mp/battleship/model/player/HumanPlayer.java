package uo.mp.battleship.model.player;

import java.util.HashSet;
import java.util.Scanner;

import uo.mp.battleship.interaction.ConsoleReader;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Damage;
import uo.mp.battleship.model.board.Ship;
import uo.mp.util.check.ArgumentChecks;

public class HumanPlayer extends Player{
	private HashSet<Coordinate> firedCoordinates = new HashSet<Coordinate>();
	public HumanPlayer(String name) {
		super(name);
		if(name==null || name.isBlank() || name.isEmpty()) {
			name="user";
		}
	}


	@Override
	public Coordinate makeChoice() {
		ConsoleReader cr = new ConsoleReader();
		Coordinate choice = cr.readCoordinates();
		while(getFiredCoordinates().contains(choice)) {
			System.out.println("This position has already been shot, choose another one");
			choice = cr.readCoordinates();
		}
		firedCoordinates.add(choice);
		return choice;
	}
	public Damage shootAt(Coordinate position) {
		if(firedCoordinates.contains(position)) {
			return getMyShips().shootAt(position);
		}else {
			return getMyShips().shootAt(position);
		}
		
	}

	/**
	 * @return the firedCoordinates
	 */
	private HashSet<Coordinate> getFiredCoordinates() {
		return firedCoordinates;
	}
}
