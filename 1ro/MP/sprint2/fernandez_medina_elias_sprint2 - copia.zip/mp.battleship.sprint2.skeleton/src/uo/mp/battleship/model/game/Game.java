package uo.mp.battleship.model.game;

import java.util.ArrayList;
import java.util.List;

import uo.mp.battleship.interaction.ConsoleWriter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Damage;
import uo.mp.battleship.model.board.Ship;
import uo.mp.battleship.model.board.Square;
import uo.mp.battleship.model.player.ComputerPlayer;
import uo.mp.battleship.model.player.HumanPlayer;
import uo.mp.battleship.model.player.Player;

public class Game {
	private boolean gameMode;
	private HumanPlayer leftPlayer;
	private ComputerPlayer rightPlayer;
	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer, int size) {
		Board blp = new Board(size);
		Board brp = new Board(size);
		leftPlayer.setMyShips(blp);
		leftPlayer.setOpponentShips(brp);
		rightPlayer.setMyShips(brp);
		rightPlayer.setOpponentShips(blp);
		this.leftPlayer = leftPlayer;
		this.rightPlayer = rightPlayer;
	}
	
	public void setDebugMode ( boolean gameMode ) {
		if(gameMode) {
			gameMode = false;
		}else {
			gameMode = true;
		}
	}
	

	public void play() {
	    // Inicializar el selector de turnos
	    TurnSelector turnSelector = new TurnSelector(leftPlayer, rightPlayer);
	    // Inicializar el escirtor
	    ConsoleWriter consoleWriter = new ConsoleWriter();

	    // Mostrar un mensaje de inicio del juego
	    System.out.println("Welcome to Battleship");

	    // Bucle principal del juego
	    while (true) {
	        // Obtener el jugador cuyo turno es ahora
	        Player currentPlayer = (turnSelector.next() == TurnSelector.PLAYER_TURN) ? leftPlayer : rightPlayer;

	        // Mostrar el mensaje de turno
	        consoleWriter.showTurn(currentPlayer.getName(), System.out);

	        // Mostrar la matriz de juego
	        consoleWriter.showGameStatus(leftPlayer.getMyShips(), rightPlayer.getMyShips(), gameMode);

	        // Obtener la coordenada elegida por el jugador actual
	        Coordinate shotCoordinate = currentPlayer.makeChoice();

	        // Realizar el disparo en el tablero del oponente
	        Damage hit = currentPlayer == leftPlayer ?
	                        rightPlayer.shootAt(shotCoordinate) :
	                        leftPlayer.shootAt(shotCoordinate);
	        boolean shot = false; 
	        if(hit==Damage.MASSIVE_DAMAGE || hit==Damage.SEVERE_DAMAGE) {
	        	 shot = true;
	        }else {
	        	 shot = false;
	        }
	        // Mostrar el resultado del disparo
	        Square square = currentPlayer.getOpponentShips().getInnerArray()[shotCoordinate.getRow()][shotCoordinate.getCol()];
	        Ship sunkShip = null;
	        boolean isTheShipSunk = false;
	        if (square.getContent() instanceof Ship) {
	            sunkShip = (Ship) square.getContent();
	            isTheShipSunk = sunkShip.isSunk();
	        }
	        consoleWriter.showShotMessage(shot, isTheShipSunk, System.out);
	        //Repetir turno
	        if(shot) {
	        	turnSelector.repeat();
	        }

	        // Mostrar la matriz de juego actualizada después del disparo
	        for(int i=0; i<5; i++) {
	        	System.out.println();
	        }
	        consoleWriter.showGameStatus(leftPlayer.getMyShips(), rightPlayer.getMyShips(), gameMode);
	        for(int i=0; i<5; i++) {
	        	System.out.println();
	        }

	        // Verificar si el juego ha terminado
	        if (leftPlayer.hasWon() || rightPlayer.hasWon()) {
	            // Mostrar el mensaje de fin de juego
	           consoleWriter.showGameOver(System.out);
	            
	            // Mostrar al ganador
	            String winner = leftPlayer.hasWon() ? leftPlayer.getName() : rightPlayer.getName();
	            consoleWriter.showWinner(winner, System.out);
	            
	            // Salir del bucle
	            break;
	        }
	    }
	}



}
