package uo.mp.battleship.model.player;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Damage;

public class ComputerPlayer extends Player {
	/**
	 * Constante de dimensión del tablero
	 */
	private static final int GRID_SIZE = 10;
	private HashSet<Coordinate> firedCoordinates = new HashSet<Coordinate>();
	public ComputerPlayer(String name) {
		super(name);
	}
	
	   @Override
	    public Coordinate makeChoice() {
	        Coordinate choice = generateRandomCoordinate();
	        while (getFiredCoordinates().contains(choice)) {
	            choice = generateRandomCoordinate();
	        }
	        firedCoordinates.add(choice);
	        return choice;
	    }

	    private Coordinate generateRandomCoordinate() {
	        Random random = new Random();
	        int row = random.nextInt(GRID_SIZE);
	        int column = random.nextInt(GRID_SIZE);
	        return new Coordinate(row, column);
	    }
	    public Damage shootAt(Coordinate position) {
			if(firedCoordinates.contains(position)) {
				return getMyShips().shootAt(position);
			}else {
				return getMyShips().shootAt(position);
			}
			
		}

		/**
		 * @return the firedCoordinates
		 */
		private HashSet<Coordinate> getFiredCoordinates() {
			return firedCoordinates;
		}

}
