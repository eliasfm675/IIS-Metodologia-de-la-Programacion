package uo.mp.util.file;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;


import uo.mp.util.check.ArgumentChecks;

/**
 * A utility class to read/write text lines 
 * from/to a compressed text file (.txt.gz) 
 */
public class ZipFileUtil {

	/**
	 * Fake method to read lines from a .gz file
	 * 
	 * Read all lines from a .gz file. A line is considered to be terminated by a line feed ('\n'). 
	 * Each item in the list (line) will contain the contents of a line, not including any line-termination characters.
	 * 
	 * @param pathToZippedFileName path to a compressed file 
	 * @return the lines from the file as a List
	 * @throws FileNotFoundException 
	 * @throws IOException
	 */
	public List<String> readLines(String pathToZippedFileName) throws FileNotFoundException {
		ArgumentChecks.isNotBlank(pathToZippedFileName);
		
		List<String> lines = new ArrayList<>();
		String line;
		BufferedReader in;
		try {						
			in = new BufferedReader(
						new InputStreamReader(new GZIPInputStream(new FileInputStream(pathToZippedFileName))));
			try {
				while ((line = in.readLine()) != null) {
					lines.add(line);
				}
			} finally {
				in.close(); 
			}
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw new RuntimeException("Error de lectura " + e.getMessage());
		}
		return lines;
	}

	/**
	 * Fake method to write lines to a .gz file
	 * 
	 * Write to a .gz file all strings in the list. Lines must be terminated by a line feed ('\n'). 
	 * Each item in the list (line) contains the contents for one line, not including any
	 * line-termination characters.
	 * @param pathToZippedFileName 	path to a compressed file 
	 * @param lines         		the List of strings to the written to the file 
	 * @throws FileNotFoundException 
	 * @throws IOException
	 */
	public void writeLines(String outZippedFileName, List<String> lines) throws FileNotFoundException  {
		ArgumentChecks.isNotBlank(outZippedFileName);
		ArgumentChecks.isNotNull(lines);
		try {
			BufferedWriter out = new BufferedWriter(
					new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(outZippedFileName))));
			try {
				for (String line : lines) {
					out.write(line);
					out.newLine();
				}
			} finally {
				out.close();
			}
		} catch (FileNotFoundException e) {
			throw e;		
		} catch (IOException e) {
			throw new RuntimeException("Error de escritura");
		}
	}

}
