package uo.mp.util.collections;

import java.util.Iterator;

import uo.mp.util.collections.List;

public class LinkedList<T> extends AbstractList<T> {
	Node head;
	private class Node{
		T element;
		Node next;
			Node(T element,Node node){
				this.element=element;
				this.next=node;
			}
	}
	public LinkedList() {
		this.numberOfElements=0;
		this.head=null;
	}

	@Override
	public int size() {
		return numberOfElements;
	}
	public void checkIndex(int index, int maxIndex) {
        if (index < 0 || index > maxIndex) {
            throw new IndexOutOfBoundsException("Index out of range [0, " + maxIndex + "]");
        }
    
		
	}

	@Override
	public boolean isEmpty() {
		return this.size()==0;
	}

	@Override
	public boolean add(T element) {
		add(size(),element);
		if(this.get(size()-1)==element) {
            return true;
        }else {
            return false;
        }
	}

	@Override
	public boolean remove(T o) {
		if (head == null) {
            return false;
        }
		if (head.element.equals(o)) {
            head = head.next;
            numberOfElements--;
            return true;
		}else {
			return false;
		}
		
	}
	@Override
	public boolean equals(Object o) {
		if(o==null)return false;
		if(o==this)return true;
		if(!(o instanceof List))return false;
		List that=(List)o;
		if(this.size()!=that.size())return false;
		for(int i=0;i<size();i++) {
			Object o1=this.get(i);
			Object o2=that.get(i);
			if(!(o1.equals(o2))) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void clear() {
		head = null;
        numberOfElements = 0;

	}

	@Override
	public T get(int index) {
		checkIndex(index, size() - 1);
        Node current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.element;
	}
	private Node getNode(int index) {
		checkIndex(index,  numberOfElements - 1);
		int pos=0;
		Node node=head;
		while(pos<index) {
			node=node.next;
			pos+=1;
		}
		return node;
	}
	@Override
	public T set(int index, T element) {
		/*
		 * 1- obtener el nodo anterior para ese indice.Para ello hay que implementar 
		 * tambien el getNode(index)
		 * 2- Crear un nuevo nodo que enlace con el siguiente que habia 
		 * 3- Hacer que el anterior enlace con el nuevo
		 * 
		 * Cuidado!No funciona con la primera posicion ya que no tiene anterior.
		 * habria que modificar la cabeza 
		 */
		checkIndex(index,numberOfElements - 1);
		if(index==0) {
			head=new Node(element,head);
		}else {
			Node previus=getNode(index-1);
			previus.next=new Node(element,previus.next);
			
		}
		
		return element;
	}

	@Override
	public void add(int index, T element) {
		checkIndex(index, numberOfElements);
        if (index == 0) {
            head = new Node(element, head);
        } else {
            Node prevNode = getNode(index - 1);
            prevNode.next = new Node(element, prevNode.next);
        }
        numberOfElements++;

	}

	@Override
	public T remove(int index) {
		 checkIndex(index, size() - 1);
	        T removedElement;
	        if (index == 0) {
	            removedElement = head.element;
	            head = head.next;
	        } else {
	            Node current = head;
	            for (int i = 0; i < index - 1; i++) {
	                current = current.next;
	            }
	            removedElement = current.next.element;
	            current.next = current.next.next;
	        }
	        numberOfElements--;
	        return removedElement;
	}

	@Override
	public int indexOf(Object o) {
		 Node current = head;
	        for (int i = 0; i < numberOfElements; i++) {
	            if (current.element.equals(o)) {
	                return i;
	            }
	            current = current.next;
	        }
	        return -1;
	}
	
	public Iterator<T> iterator(){
		return (Iterator<T>) new LinkedListIterator();
	}
	
	private class LinkedListIterator implements Iterator<Object> {
		Node next;
		int nextIndex;
		Node lastReturned;
		
		private LinkedListIterator() {
			next = head;
			nextIndex = 0;
			lastReturned=null;
		}
		
		@Override
		public boolean hasNext() {
			return next!=null;
		}
		
		@Override
		public Object next() {
			lastReturned = next;
			next=next.next;
			nextIndex++;
			return lastReturned.element;
		}
		
		@Override
		public void remove(){
			if(lastReturned==null)
				throw new IllegalStateException("No es posible eliminiar sin hacer next previamente");
			lastReturned = null;
			LinkedList.this.remove(nextIndex - 1);
			nextIndex--;
			numberOfElements--;
		}
		
		
			
		}

}
