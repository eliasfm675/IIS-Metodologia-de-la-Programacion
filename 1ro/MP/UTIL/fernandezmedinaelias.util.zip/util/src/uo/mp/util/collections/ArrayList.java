package uo.mp.util.collections;

import java.util.Iterator;
import java.util.NoSuchElementException;

import uo.mp.util.collections.List;

public class ArrayList<T> extends AbstractList<T>{
	T [] elements;
	@SuppressWarnings("unchecked")
	public ArrayList() {
		super();
		numberOfElements=0;
		elements=(T[]) new Object[20];
	}
	@Override
	public void clear() {
		   elements = (T[]) new Object[elements.length];
	       numberOfElements = 0;

	}

	@Override
	public T get(int index) {
		checkIndex(index, numberOfElements - 1);
        return elements[index];
	}
	
	public void checkIndex(int index, int maxIndex) {
        if(index<0 || index> maxIndex) {
            throw new IndexOutOfBoundsException("Index out of range [0, " + maxIndex + "]");
        }
    }

	@Override
	public T set(int index, T element) {
		checkIndex(index, numberOfElements - 1);
        T oldValue = elements[index];
        elements[index] = element;
        return oldValue;
	}

	@Override
	public void add(int index, T element) {
		 checkIndex(index, numberOfElements);
	        if (numberOfElements == elements.length) {
	            resize();
	        }
	        if(numberOfElements != 0)
	        	for (int i = numberOfElements; i > index; i--) {
	            elements[i] = elements[i - 1];
	        	}
	        elements[index] = element;
	        numberOfElements++;

	}

	@Override
	public T remove(int index) {
		checkIndex(index, numberOfElements - 1);
        T removedElement = elements[index];
        for (int i = index; i < numberOfElements - 1; i++) {
            elements[i] = elements[i + 1];
        }
        elements[numberOfElements - 1] = null; 
        numberOfElements--;
        return removedElement;
	}

	@Override
	public int indexOf(Object o) {
		  for (int i = 0; i < numberOfElements; i++) {
	            if (elements[i].equals(o)) {
	                return i;
	            }
	        }
	        return -1;
	}
	@Override
	public int size() {
		return numberOfElements;
	}
	
	@SuppressWarnings("unchecked")
	public Iterator<T> iterator(){
	return (Iterator<T>) new ArrayListIterator();
	}
	
	private class ArrayListIterator implements Iterator<Object> {
		int index;
		Object lastObject;
		
		public ArrayListIterator(){
			index=0;
			lastObject=null;
		}
		
		@Override
		public boolean hasNext() {
			return index < size();
		}
		
		@Override
		public Object next() {
			if(!hasNext())
				throw new NoSuchElementException("No hay elementos");
			
			lastObject = elements[index];
			index++;
			return lastObject;
			
		}
		
		@Override
		public void remove() {
			if(lastObject==null)
				throw new IllegalStateException("");
			lastObject = null;
			ArrayList.this.remove(index);
			index--;
			numberOfElements--;
		}
		
	}
	private void resize() {
        int newCapacity = elements.length * 2;
        T[] newElements = (T[]) new Object[newCapacity];
        for (int i = 0; i < elements.length; i++) {
            newElements[i] = elements[i];
        }
        elements = newElements;
    }

}
