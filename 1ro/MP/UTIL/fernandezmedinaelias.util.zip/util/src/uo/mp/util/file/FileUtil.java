package uo.mp.util.file;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;


import uo.mp.util.check.ArgumentChecks;

/**
 * A utility class to read/write text lines from/to a text file
 */
public class FileUtil {

	

	
	public List<String> readLines(String inFileName) throws FileNotFoundException {
		ArgumentChecks.isNotNull(inFileName);
		ArgumentChecks.isNotBlank(inFileName);
		List<String> res = new LinkedList<>();
		BufferedReader in = new BufferedReader(new FileReader(inFileName));
		String line;		
		
		try {
			try {
				while ((line = in.readLine()) != null) {
					res.add(line);
				}
			} finally {
				in.close();
			}		
		} catch (IOException e) {
			throw new RuntimeException(" Error de lectura");
		}		
		return res;
	}

	public void writeLines(String outFileName, List<String> lines)  {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(outFileName));
			try {
				for (String line : lines) {
					out.write(line);
					;
					out.newLine();
				}
			} finally {
				out.close();
			}	
		} catch (IOException e) {
			throw new RuntimeException("Error de entrada /salida");
		}
	}

}
