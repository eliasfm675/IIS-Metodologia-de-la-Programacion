/**
 * 
 */
package uo.mp.lab06.greenhouse.electronicdevices;

/**
 * 
 */
public interface ElectronicDevices {
	String scan();
}
