package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

public class Game2048CompactUpTest {
	
}
