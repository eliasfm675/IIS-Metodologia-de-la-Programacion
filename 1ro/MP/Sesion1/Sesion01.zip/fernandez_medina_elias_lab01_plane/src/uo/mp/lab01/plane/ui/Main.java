/**
 * 
 */
package uo.mp.lab01.plane.ui;

import uo.mp.lab01.plane.model.Plane;
import uo.mp.lab01.plane.model.Person;

/**
 * @author UO299673
 * @version 30-01-2024
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PlaneApp().run();
	}

}
