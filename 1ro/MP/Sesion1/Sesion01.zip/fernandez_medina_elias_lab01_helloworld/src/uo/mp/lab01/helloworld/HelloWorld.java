/**
 * 
 */
package uo.mp.lab01.helloworld;

/**
 * @author UO299673
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hola mundo!!! ");
		System.out.println("Me llamo " + args[0] + " " + args[1] + " " + args[2]);

	}

}
