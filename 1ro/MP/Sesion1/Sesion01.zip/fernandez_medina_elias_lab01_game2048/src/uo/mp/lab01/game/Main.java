package uo.mp.lab01.game;

import uo.mp.lab01.game.ui.GameApp;

public class Main {

	public static void main(String[] args) {
		new GameApp().run();
	}

}
