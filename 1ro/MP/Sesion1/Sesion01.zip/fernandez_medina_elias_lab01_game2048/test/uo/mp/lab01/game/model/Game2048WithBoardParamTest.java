package uo.mp.lab01.game.model;

import static org.junit.Assert.*;


import org.junit.Test;

import uo.mp.lab01.game.model.Game2048;

public class Game2048WithBoardParamTest {
	
	
}
