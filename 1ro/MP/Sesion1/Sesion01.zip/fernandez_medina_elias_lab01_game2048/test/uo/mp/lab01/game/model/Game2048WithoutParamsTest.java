package uo.mp.lab01.game.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class Game2048WithoutParamsTest {
	

}
