package uo.mp.battleship;

import uo.mp.battleship.console.ConsoleGameInteractor;
import uo.mp.battleship.console.ConsoleGamePresenter;
import uo.mp.battleship.console.ConsoleSessionInteractor;
import uo.mp.battleship.model.ranking.GameRanking;
import uo.mp.battleship.session.GameSession;

public class Main {

	private GameSession session;

	public static void main(String[] args) {
		new Main()
			.configure()
			.run();
	}
	

	private Main configure() {
		session = new GameSession();
		session.setSessionInteractor( new ConsoleSessionInteractor() );
		session.setGameInteractor( new ConsoleGameInteractor() );
		session.setGamePresenter( new ConsoleGamePresenter() );
		session.setGameRanking( new GameRanking() );
		return this;
	}

	private void run() {
		session.run();
	}


}
