/**
 * 
 */
package uo.mp.battleship.console;

import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.player.Player;

/**
 * @author elias
 *
 */
public class ConsoleGamePresenter implements GamePresenter{

	public void showGameStatus(Board left, Board right, boolean debugMode) {
		StringBuilder sb = new StringBuilder();
		char[] letters = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','V','W','X','Y','Z'};
		sb.append("        MY SHIPS		                         OPONNENT'S SHIPS").append("\n");
		sb.append("  ");
		for(int i=0; i<2; i++) {
			for(int j=0; j<left.getFullStatus()[0].length; j++) {
				if(j==0) {
					sb.append("  ").append(letters[j]).append(" ");
				}else {
					sb.append(letters[j]).append(" ");
				}
				
				}
			if(i==1) {
				break;
			}
			sb.append("			        ");
		}
		sb.append("\n");
		//sb.append("  A B C D E F J H I J").append("			  A B C D E F G H I J").append("\n");
		char[][] boardLeft = left.getFullStatus();
		char[][] boardRight;
		if(debugMode) {
			 boardRight = right.getFullStatus();
		}else {
			 boardRight = right.getMinimalStatus();
		}
		for (int i = 0; i < boardLeft.length; i++) {
			if(i<10) {
			sb.append("   ").append(i+1).append("|");
			for (int j = 0; j < boardLeft[i].length; j++) {
				sb.append(boardLeft[i][j]).append("|");
			}
			sb.append("			");
			sb.append(" ").append(i+1).append("|");
			}else {
				sb.append(i+1).append("|");
				for (int j = 0; j < boardLeft[i].length; j++) {
					sb.append(boardLeft[i][j]).append("|");
				}
				sb.append("			");
				sb.append(i+1).append("|");
			}
			
			for (int j = 0; j < boardRight[i].length; j++) {
				sb.append(boardRight[i][j]).append("|");
			}
			sb.append("\n");
		}
		System.out.println(sb.toString());
	}	

	/*
	 * Expected message 
	 * 		The winner is ... winner name
	 */
	public void showWinner(Player player) {
		System.out.println("The winner is " + player.getName());
	}

	/*
	 * Expected message
	 * 		The game is over!!
	 */
	public void showGameOver() {
		System.out.println("The game is over!!");
	}
	
	/*
	 * Expected message
	 * 		Now the turn is for the player player name
	 */
	public void showTurn(Player player) {
		System.out.println("Now the turn is for the player " + player.getName());
	}

	/*
	 * Expected message
	 * 		Shoot at user-friendly
	 */
	public void showShootingAt(Coordinate position) {
		System.out.println("Shoot at " + position);
	}

	/*
	 * Expected message
	 * 		Depending on the shot result:
	 * 		MISS, HIT!! (sprint 1)
	 * 		MISS, HIT!!. Continue, HIT AND SUNK!!. Continue (from sprint 2 on)
	 */
	public void showShotMessage(Damage damage) {
		if(damage == Damage.SEVERE_DAMAGE) {
			System.out.println("HIT! Continue");
		}else if(damage == Damage.MASSIVE_DAMAGE){
			System.out.println("Hit and Sunk!");
		}
		
		else {
			System.out.println("MISS!!");
		}
	}

	@Override
	public void showErrorMessage(String message) {
		System.out.println(message);
		
	}
}
