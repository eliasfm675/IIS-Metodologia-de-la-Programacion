/**
 * 
 */
package uo.mp.battleship.model.board.squares;

/**
 * @author 
 *
 */
public class Water implements Target{

	public Damage shootAt() {
		return Damage.NO_DAMAGE;
	}
	
	public char toChar() {
		return ' ';
	}
	
	public char toFiredChar () {
		return 'ø';
	}
	
}
