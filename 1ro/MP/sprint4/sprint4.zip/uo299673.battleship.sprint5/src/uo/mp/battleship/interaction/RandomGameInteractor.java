/**
 * 
 */
package uo.mp.battleship.interaction;

import java.util.Random;

import uo.mp.battleship.model.board.Coordinate;

/**
 * @author 
 *
 */
public class RandomGameInteractor implements GameInteractor{
	
	private int size;
	
	public RandomGameInteractor(int size) {
		this.size = size;
	}

	@Override
	public Coordinate getTarget() {
		Random random = new Random();
		int row = random.nextInt(size);
        int column = random.nextInt(size);
        return new Coordinate(row, column);
	}

	
}
