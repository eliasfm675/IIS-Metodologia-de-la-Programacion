/**
 * 
 */
package uo.mp.battleship.session;

import java.util.List;

import uo.mp.battleship.exceptions.InvalidCoordinateException;
import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.interaction.RandomGameInteractor;
import uo.mp.battleship.interaction.SessionInteractor;
import uo.mp.battleship.model.game.Game;
import uo.mp.battleship.model.player.Player;
import uo.mp.battleship.model.ranking.GameRanking;
import uo.mp.battleship.model.ranking.Score;
import uo.mp.util.console.Console;

/**
 * 
 */
public class GameSession {
	private static final int EXIT = 0;
	private static final int NUMBER_OF_OPTIONS = 4;
	private GameInteractor interactor;
	private GamePresenter presenter;
	private SessionInteractor sInteractor;
	private GameRanking ranking = new GameRanking();
	private Player humanPlayer;
	private Player computerPlayer;
	private Game game;
	
	public void run() {
		try {
			String name = sInteractor.askUserName();
			humanPlayer = new Player(name);
			humanPlayer.setInteractor(interactor);
			computerPlayer = new Player("Computer");
			computerPlayer.setInteractor(new RandomGameInteractor(10));
			while(true) {
				sInteractor.showMenu();
				int option=sInteractor.askNextOption();
				processOption(option);
				if(option == 0)
					break;
			}
		}catch (RuntimeException e) {
			Console.printError("FATAL ERROR:");
			Console.printError( e.getMessage() );
			Console.printError("The program must stop execution.");	
		}catch (InvalidCoordinateException e) {
			presenter.showErrorMessage(e.getMessage());
		}
		
	}

	private void processOption(int option) throws InvalidCoordinateException {
		switch (option) {
		case 0: 
			sInteractor.sayGoodbye();
			break;
		case 1:
			game =new Game(humanPlayer,computerPlayer);
			game.setDebugMode(sInteractor.askDebugMode());
			game.setPresenter(presenter);
			game.play();
			if(sInteractor.doYouWantToRegisterYourScore()) {
				Score result = new Score(humanPlayer.getName(), GameLevel.SEA, game.getInitialTime(), game.getFinalTime());
				ranking.append(result);
			}
	
			break;
				
		case 2:
			sInteractor.showPersonalRanking(ranking.getRankingFor(humanPlayer.getName()));
			break;
		case 3:
			sInteractor.showRanking(ranking.getRanking());
			break;
		}
				
	}

	/**
	 * @param interactor the interactor to set
	 */
	public void setGameInteractor(GameInteractor interactor) {
		this.interactor = interactor;
	}

	/**
	 * @param presenter the presenter to set
	 */
	public void setGamePresenter(GamePresenter presenter) {
		this.presenter = presenter;
	}

	/**
	 * @param sInteractor the sInteractor to set
	 */
	public void setSessionInteractor(SessionInteractor sInteractor) {
		this.sInteractor = sInteractor;
	}

	/**
	 * @param ranking the ranking to set
	 */
	public void setGameRanking(GameRanking ranking) {
		this.ranking = ranking;
	}

	
}
