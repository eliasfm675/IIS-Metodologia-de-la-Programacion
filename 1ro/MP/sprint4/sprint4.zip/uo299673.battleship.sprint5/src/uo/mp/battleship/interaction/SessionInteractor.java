package uo.mp.battleship.interaction;

import java.util.List;

import uo.mp.battleship.model.ranking.Score;
import uo.mp.battleship.session.GameLevel;

public interface SessionInteractor {
	/**
	 * Asks the user for the game level
	 * @return a GameLevel value (@see GameLevel)
	 */
	GameLevel askGameLevel();

	/**
	 * @return the user name for the session
	 */
	String askUserName();
	
	/**
	 * Shows the menu
	 */
	void showMenu();
	
	/**
	 * @return a value >= 0 indicating the option. 
	 * Return value == 0 represents the exit option 
	 */
	int askNextOption();

	/**
	 * Ask the user if he/she wants to store the score
	 * @return boolean yes or no
	 */
	boolean doYouWantToRegisterYourScore();

	/**
	 * Shows the user the general ranking
	 * The ranking must already be sorted
	 * @param ranking
	 */
	void showRanking(List<Score> ranking);
	
	/**
	 * Shows the user its personal ranking
	 * The ranking must already be sorted
	 * @param ranking
	 */
	void showPersonalRanking(List<Score> ranking);


	/**
	 * Shows the user a message in the standard error
	 * @param message
	 */
	void showErrorMessage(String message);
	
	/**
	 * Shows the user the message in the standard error, but also warns a non-recoverable error have 
	 * happened and the program is about to stop 
	 * @param message
	 */
	void showFatalErrorMessage(String message);


	/**
	 * Asks the user whether they prefer to play in debug mode or not
	 * 
	 * @return true if they want to play debug; false otherwise
	 */
	boolean askDebugMode();
	
	/**
	 * Displays a polite goodbye message when the user stops playing
	 */
	void sayGoodbye();
}
