/**
 * 
 */
package uo.mp.battleship.model.ranking;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import uo.mp.battleship.session.GameLevel;

/**
 * 
 */
public class Score {
	private String userName;
	private GameLevel level;
	private LocalDateTime initial;
	private LocalDateTime finalTime;

	public Score(String userName, GameLevel level, LocalDateTime initial, LocalDateTime finalTime) {
		this.userName = userName;
		this.level = level;
		this.finalTime = finalTime;
		this.initial = initial;

	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the level
	 */
	public GameLevel getLevel() {
		return level;
	}

	public long getTime() {
		return ChronoUnit.SECONDS.between(initial, finalTime);
	}

	public LocalDateTime getDate() {
		return finalTime;
	}

	public String toString() {
		return getUserName()+"\t\t"+ 
				getCurrentDate() + "\t\t" + getCurrentHour() + 
					"\t\t" + getLevel() + "\t" + getTime();

	}
	
	public String personalToString() {
		return getCurrentDate() + "\t\t" + getCurrentHour() + 
					"\t\t" + getLevel() + "\t" + getTime();

	}

	private String getCurrentHour() {
		LocalDateTime locaDate = LocalDateTime.now();
		int hours = locaDate.getHour();
		int minutes = locaDate.getMinute();
		int seconds = locaDate.getSecond();
		String time = String.format("%d:%d:%d", hours,minutes,seconds);
		return time;

	}
	
	private String getCurrentDate() {
		LocalDateTime locaDate = LocalDateTime.now();
		int day = locaDate.getDayOfMonth();
		int month = locaDate.getMonthValue();
		int year = locaDate.getYear();
		String date = String.format("%d-%d-%d", day,month,year);
		return date;

	}

}
