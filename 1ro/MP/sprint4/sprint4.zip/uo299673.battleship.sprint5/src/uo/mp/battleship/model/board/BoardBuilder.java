package uo.mp.battleship.model.board;

import java.util.List;

import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.battleship.model.board.squares.Water;

class BoardBuilder {

	static Square[][] build(int size, List<Ship> fleet) {
		Square[][] board = new Square[size][size];
		for(int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				board[i][j] = new Square();
			}
		}

		board[0][0].setContent(fleet.get(0));
		board[0][2].setContent(fleet.get(1));
		board[0][4].setContent(fleet.get(2));
		board[0][6].setContent(fleet.get(3));
		board[2][0].setContent(fleet.get(4));
		board[2][1].setContent(fleet.get(4));
		board[2][3].setContent(fleet.get(5));
		board[2][4].setContent(fleet.get(5));
		board[2][6].setContent(fleet.get(6));
		board[2][7].setContent(fleet.get(6));
		board[4][0].setContent(fleet.get(7));
		board[4][1].setContent(fleet.get(7));
		board[4][2].setContent(fleet.get(7));
		board[4][4].setContent(fleet.get(8));
		board[4][5].setContent(fleet.get(8));
		board[4][6].setContent(fleet.get(8));
		board[6][4].setContent(fleet.get(9));
		board[6][5].setContent(fleet.get(9));
		board[6][6].setContent(fleet.get(9));
		board[6][7].setContent(fleet.get(9));
		
		for(int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				if(!board[i][j].hasContent()) {
					board[i][j].setContent(new Water());
				}
			}
		}
		
		return board;
	}
}