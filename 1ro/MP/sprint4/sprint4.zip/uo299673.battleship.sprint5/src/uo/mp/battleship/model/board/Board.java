package uo.mp.battleship.model.board;

import java.util.ArrayList;
import java.util.List;

import uo.mp.battleship.exceptions.InvalidCoordinateException;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.util.check.ArgumentChecks;

public class Board {

	private Square[][] board;
	private List<Ship> fleet = new ArrayList<Ship>();

	public Board(int size) {
		board = new Square[size][size];
		fleet.add(new Ship(1));
		fleet.add(new Ship(1));
		fleet.add(new Ship(1));
		fleet.add(new Ship(1));
		fleet.add(new Ship(2));
		fleet.add(new Ship(2));
		fleet.add(new Ship(2));
		fleet.add(new Ship(3));
		fleet.add(new Ship(3));
		fleet.add(new Ship(4));
		board = BoardBuilder.build(size, fleet);
	}
	
	protected Board(Square[][] arg) {
		this.board = arg;
	}

	public Damage shootAt(Coordinate position) throws InvalidCoordinateException {
        try {
            int x = position.getX();// Obtengo la pos x
            int y = position.getY();// Obtengo la pos y
            ArgumentChecks.isTrue((x >=0 && x <= board.length) && (y >=0 && y <= board[0].length), null);
            return board[y][x].shootAt();
        }catch(IllegalArgumentException e) {
            throw new InvalidCoordinateException(position);
        }

    }

	public boolean isFleetSunk() {
		for (Ship ship : fleet) {
			if(!ship.isSunk()) {
				return false;
			}
		}
		return true;
	}

	public int getSize() {

		if (board != null && board.length > 0 && board[0].length > 0) {// Tablero no nulo o ya se le ha asignado uno(no
																		// 0).
			return board.length;
		}

		else {
			return 0;
		}
	}

	public char[][] getFullStatus() {
		char[][] isShot = new char[board.length][board[0].length];
		for(int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				isShot[i][j] = board[i][j].toChar();
			}
		}
		return isShot;
	}


	public char[][] getMinimalStatus() {
		char[][] minStat = new char[board.length][board[0].length];
		
		for (int i = 0; i < minStat.length; i++) {
			for (int j = 0; j < minStat.length; j++) {
				if(!board[i][j].isShot()) {
					minStat[i][j] = ' ';
				}else {
					minStat[i][j] = board[i][j].toChar();
				}
			}
		}
		return minStat;
	}
}
