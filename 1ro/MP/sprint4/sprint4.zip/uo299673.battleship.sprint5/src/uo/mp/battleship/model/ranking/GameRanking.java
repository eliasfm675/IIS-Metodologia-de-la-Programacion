package uo.mp.battleship.model.ranking;

import java.util.ArrayList;
import java.util.List;

public class GameRanking {
	private List<Score> scores = new ArrayList<Score>();
	
	public void append(Score score) {
		scores.add(score);
	}
	
	public List<Score> getRanking(){
		List<Score> scoresCopy = new ArrayList<Score>();
		for(Score score: scores) {
			scoresCopy.add(score);
		}
		return scoresCopy;
	}
	
	public List<Score> getRankingFor(String username){
		List<Score> scoresCopy = new ArrayList<Score>();
		for(Score score: scores) {
			if(score.getUserName().equals(username))
				scoresCopy.add(score);
		}
		return scoresCopy;
	}

}
