/**
 * 
 */
package uo.mp.battleship.model.board;

/**
 * @author 
 *
 */
public enum Direction {
	NORTH, EAST, WEST, SOUTH;
}
