/**
 * 
 */
package uo.mp.battleship.model.board;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * @author 
 *
 */
public class CoordinateTest {
	
	/*
	 * Casos:
	 * 
	 * 1.- Comprueba un Coordinate para columna A, dirección Oeste
	 * 2.- Comprueba un Coordinate para fila 0, dirección Norte
	 * 3.- Comprueba todas las direcciones con un Coordinate en fila y columna diferente a 0
	 */
	
	
	/**
	 * GIVEN a coordinate with a west direction
	 * WHEN created another coordinate in the good direction
	 * THEN it must the right direction
	 */
	@Test
    public void testGoWest() {
        Coordinate initialCoordinate = new Coordinate(1, 1);
        Coordinate expectedCoordinate = new Coordinate(1, 0);
        assertEquals(expectedCoordinate, initialCoordinate.go(Direction.WEST));
    }

	/**
	 * GIVEN a coordinate with a north direction different of 0
	 * WHEN created another coordinate in the good direction
	 * THEN it must the right direction
	 */
    @Test
    public void testGoNorth() {
        Coordinate initialCoordinate = new Coordinate(1, 1);
        Coordinate expectedCoordinate = new Coordinate(0, 1);
        assertEquals(expectedCoordinate, initialCoordinate.go(Direction.NORTH));
    }

    /**
	 * GIVEN a coordinate with a all directions
	 * WHEN created others coordinates in the good direction
	 * THEN it must the right direction
	 */
    @Test
    public void testGoAllDirections() {
        Coordinate initialCoordinate = new Coordinate(1, 1);

        // Comprobación hacia el Oeste
        Coordinate westCoordinate = new Coordinate(1, 0);
        assertEquals(westCoordinate, initialCoordinate.go(Direction.WEST));

        // Comprobación hacia el Norte
        Coordinate northCoordinate = new Coordinate(0, 1);
        assertEquals(northCoordinate, initialCoordinate.go(Direction.NORTH));

        // Comprobación hacia el Este
        Coordinate eastCoordinate = new Coordinate(1, 2);
        assertEquals(eastCoordinate, initialCoordinate.go(Direction.EAST));

        // Comprobación hacia el Sur
        Coordinate southCoordinate = new Coordinate(2, 1);
        assertEquals(southCoordinate, initialCoordinate.go(Direction.SOUTH));
    }
}
