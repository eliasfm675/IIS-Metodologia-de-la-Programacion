/**
 * 
 */
package uo.mp.battleship.model.board;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import uo.mp.battleship.exceptions.InvalidCoordinateException;

/**
 * @author 
 *
 */
public class IsFleetSunkTest {

	/*
	 * 1. Todos los barcos están hundidos. Devuelve true. 
	 * 2. Todos los barcos, salvo uno que le falta una posición sin disparar, están hundidos. 
	 * 	  Devuelve false.
	 * 3. Varios barcos no han sido disparados. Devuelve false.
	 */
	
	
	/**
	 * GIVEN
	 * WHEN
	 * THEN
	 * @throws InvalidCoordinateException 
	 */
	@Test
	public void testIsFleetSunk1() throws InvalidCoordinateException {
		Board board = new Board(10);
		for(int i = 0; i < board.getSize(); i++) {
			for (int j = 0; j < board.getSize(); j++) {
				board.shootAt(new Coordinate(i, j));
			}
		}
		assertTrue(board.isFleetSunk());
	}
	
	/**
	 * GIVEN
	 * WHEN
	 * THEN
	 * @throws InvalidCoordinateException 
	 */
	@Test
	public void testIsFleetSunk2() throws InvalidCoordinateException {
		Board board = new Board(10);
		boolean ship = true;
		for(int i = 0; i < board.getSize(); i++) {
			for (int j = 0; j < board.getSize(); j++) {
				if(ship) {
					ship = false;
					continue;
				}
				board.shootAt(new Coordinate(i, j));
				
			}
		}
		assertFalse(board.isFleetSunk());
	}
	
	/**
	 * GIVEN
	 * WHEN
	 * THEN
	 * @throws InvalidCoordinateException 
	 */
	@Test
	public void testIsFleetSunk3() throws InvalidCoordinateException {
		Board b = new Board(10);
		b.shootAt(new Coordinate(0, 0));
		b.shootAt(new Coordinate(0, 2));
		b.shootAt(new Coordinate(2, 0));
		b.shootAt(new Coordinate(1, 2));
		assertFalse(b.isFleetSunk());
	}

}
