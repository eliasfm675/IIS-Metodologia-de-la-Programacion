package uo.mp.lab11.marker;

import uo.mp.lab11.marker.simulator.Simulator;

public class Main {

	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		new Simulator().start();	
	}
}
