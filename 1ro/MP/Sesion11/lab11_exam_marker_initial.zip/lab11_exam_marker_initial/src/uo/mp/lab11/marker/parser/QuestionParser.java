package uo.mp.lab11.marker.parser;

import java.util.LinkedList;
import java.util.List;

import uo.mp.lab11.marker.model.question.ChoiceQuestion;
import uo.mp.lab11.marker.model.question.GapQuestion;
import uo.mp.lab11.marker.model.question.Question;
import uo.mp.lab11.marker.model.question.ValueQuestion;

public class QuestionParser {

	/**
	 * 
	 * @param lines
	 * @return
	 * @throws IllegalArgumentException if lines is null
	 */
	public List<Question> parse(List<String> lines) {
		List<Question> res = new LinkedList<>();
		
		res.add(new ChoiceQuestion(1, 1.0, "a"));
		res.add(new ChoiceQuestion(2, 1.0, "b"));
		res.add(new GapQuestion(3, 0.5, "stuff"));
		res.add(new GapQuestion(4, 0.5, "computer"));
		res.add(new ValueQuestion(5, 1.5, 12.5));
		res.add(new ValueQuestion(6, 1.5, 100.0));
		res.add(new GapQuestion(7, 1.0, "polymorphism"));
		res.add(new ValueQuestion(8, 1.0, 256.0));
		res.add(new ChoiceQuestion(9, 0.5, "c"));
		res.add(new GapQuestion(10, 1.5, "abstract"));


		return res;
	}
			
			
			

}
