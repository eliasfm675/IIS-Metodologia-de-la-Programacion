package uo.mp.battleship.model.player;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;

public class ComputerPlayer {


	public ComputerPlayer(String name) {
	}

	public String getName() {
		return null;
	}

	public void setMyShips(Board board) {
		
	}

	public void setOpponentShips(Board board) {
		
	}

	public boolean shootAt(Coordinate position) {
		return false;
	}

	public Board getMyShips() {
		return null;
	}

	public Board getOpponentShips() {
		return null;
	}

	public boolean hasWon() {
		return false;
	}
	
	public Coordinate makeChoice() {

		return null;
	}

}
