package uo.mp.battleship.model.board;

import java.util.ArrayList;

public class Board {
	private ArrayList<Integer> shipsList;
	private int[][] grid;
	
	public Board( int size ) {
		grid = BoardBuilder.build();
	}

	public boolean shootAt(Coordinate position) {
		if(grid[position.getCol()][position.getRow()]>0) {
			grid[position.getCol()][position.getRow()]*=-1;
			return true;
		}else if(grid[position.getCol()][position.getRow()]==0) {
			
		}
	}	
	
	public boolean isFleetSunk() {
		return true;
	}
	
	
	public int getSize() {
		return -1;
	}

	public char[][] getFullStatus() {
		return null;
	}

	public char[][] getMinimalStatus() {
		return null;
		
	}

}
