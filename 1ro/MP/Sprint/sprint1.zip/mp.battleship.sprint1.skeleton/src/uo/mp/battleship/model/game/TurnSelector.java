package uo.mp.battleship.model.game;

class TurnSelector {
	private static final int PLAYER_TURN = 1;
	private static final int MACHINE_TURN = 0;
	private int turn;
	TurnSelector() {
		setTurn(PLAYER_TURN);
	}
	
	private int getTurn() {
		return turn;
	}

	private void setTurn(int turn) {
		this.turn = turn;
	}

	int next() {
		if(turn==PLAYER_TURN) {
			turn=MACHINE_TURN;
		}else{
			turn=PLAYER_TURN;
		}
		return turn;
	}
}

