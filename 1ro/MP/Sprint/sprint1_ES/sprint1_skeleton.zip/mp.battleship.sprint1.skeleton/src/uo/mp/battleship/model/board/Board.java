package uo.mp.battleship.model.board;

public class Board {

	public Board( int size ) {
	}

	public boolean shootAt(Coordinate position) {
		return false;
	}	
	
	public boolean isFleetSunk() {
		return true;
	}
	
	
	public int getSize() {
		return -1;
	}

	public char[][] getFullStatus() {
		return null;
	}

	public char[][] getMinimalStatus() {
		return null;
		
	}

}
