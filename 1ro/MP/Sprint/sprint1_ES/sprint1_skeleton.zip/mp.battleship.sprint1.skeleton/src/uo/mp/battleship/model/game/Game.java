package uo.mp.battleship.model.game;

import uo.mp.battleship.model.player.ComputerPlayer;
import uo.mp.battleship.model.player.HumanPlayer;

public class Game {

	
	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer) {
	}
	
	public void setDebugMode ( boolean gameMode ) {
	}

	public void play() {
	}


}
