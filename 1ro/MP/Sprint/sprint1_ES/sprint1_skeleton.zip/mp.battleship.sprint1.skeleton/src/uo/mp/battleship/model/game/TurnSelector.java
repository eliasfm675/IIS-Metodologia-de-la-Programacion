package uo.mp.battleship.model.game;

class TurnSelector {

	TurnSelector() {
	}
	
	int next() {
		return -1;
	}
}

