package uo.mp.battleship.model.board;

public class Coordinate {
		
	public Coordinate(int col, int row) {
	}

	public int getCol() {
		return -1;
	}

	public int getRow() {
		return -1;
	}
	
	@Override
	public String toString() {
		return null;
	}

	public String toUserString() {
		return null;
	}

}
