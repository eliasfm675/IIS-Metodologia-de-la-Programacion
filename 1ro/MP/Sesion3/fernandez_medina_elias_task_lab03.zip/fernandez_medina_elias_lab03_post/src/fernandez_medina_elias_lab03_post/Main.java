package fernandez_medina_elias_lab03_post;


public class Main {
	public static void main(String[] args) {
        NetworkApp networkApp = new NetworkApp();
        networkApp.simulateClient();
    }
}
